<?php

namespace Modules\CartModule\Http\Controllers\Api\V1\Customer;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\BookingModule\Entities\Booking;
use Modules\BookingModule\Http\Traits\BookingTrait;
use Modules\CartModule\Entities\Cart;
use Modules\CartModule\Traits\AddedToCartTrait;
use Modules\CartModule\Traits\CartTrait;
use Modules\PromotionManagement\Entities\Coupon;
use Modules\ProviderManagement\Entities\Provider;
use Modules\ServiceManagement\Entities\Service;
use Modules\ServiceManagement\Entities\Variation;
use Modules\ServiceManagement\Services\PricingEngine;
use Modules\UserManagement\Entities\Guest;
use Modules\UserManagement\Entities\User;
use Ramsey\Uuid\Uuid;

class CartController extends Controller
{
    private Cart $cart;
    private Service $service;
    private Variation $variation;
    private User $user;

    private Booking $booking;
    private Coupon $coupon;
    private Provider $provider;
    private Guest $guest;
    private bool $isCustomerLoggedIn;
    private mixed $customerUserId;

    use CartTrait, AddedToCartTrait;

    public function __construct(Cart $cart, Service $service, Variation $variation, User $user, Provider $provider, Guest $guest, Request $request, Booking $booking, Coupon $coupon, private readonly PricingEngine $pricingEngine)
    {
        $this->cart = $cart;
        $this->service = $service;
        $this->variation = $variation;
        $this->user = $user;
        $this->provider = $provider;
        $this->guest = $guest;
        $this->booking = $booking;
        $this->coupon = $coupon;

        $this->isCustomerLoggedIn = (bool)auth('api')->user();
        if ($this->isCustomerLoggedIn) {
            $this->customerUserId = auth('api')->user()->id;
        } else {
            // A guest id is not an authentication credential. Bind all cart operations
            // to the server-issued guest payment token and its existing Guest row.
            $principal = app(\Modules\PaymentModule\Services\PaymentPrincipal::class)->resolve($request);
            abort_unless(($principal['is_guest'] ?? false)
                && (string) ($principal['id'] ?? '') === (string) $request->input('guest_id'),
                401, 'guest_session_required');
            $this->customerUserId = $principal['id'];
        }
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function addToCart(Request $request): JsonResponse
    {
        $data = $request->validate([
            'provider_id' => 'nullable|uuid', 'service_id' => 'required|uuid', 'variant_key' => 'required|string',
            'quantity' => 'required|integer|min:1|max:1000', 'field_answers' => 'sometimes|array',
            'branch_service_area_id' => 'nullable|uuid',
            'guest_id' => $this->isCustomerLoggedIn ? 'nullable' : 'required|uuid',
        ]);
        return DB::transaction(function () use ($data, $request): JsonResponse {
            $service = app(\Modules\ServiceManagement\Services\DirectServicePolicy::class)->catalog((string) Config::get('zone_id'))->findOrFail($data['service_id']);
            abort_unless($service->pricing_type === 'fixed', 422, 'service_requires_quotation');
            $variation = app(\Modules\ServiceManagement\Services\ServicePriceResolver::class)->resolve($service->id, $data['variant_key'], Config::get('zone_id'));
            $provider = $data['provider_id'] ?? null;
            $area = $data['branch_service_area_id'] ?? null;
            abort_if($area && !$provider, 422, 'branch_required_for_area');
            if ($provider) abort_unless(app(\Modules\ServiceManagement\Services\DirectServicePolicy::class)->available($provider, $service->id, $area), 422, 'service_unavailable_for_branch');
            $quantity = (int) $data['quantity'];
            $answers = $data['field_answers'] ?? [];
            $pre = $this->pricingEngine->calculate($service, $variation, $quantity, (string) Config::get('zone_id'), $provider, $area, now(), fieldAnswers: $answers);
            $answers = array_map(fn ($answer) => ['field_id' => $answer['field_id'], 'value' => $answer['value']], $pre->execution['field_answers']);
            $basic = basic_discount_calculation($service, $pre->adjustedPrice);
            $campaign = campaign_discount_calculation($service, $pre->adjustedPrice);
            $pricing = $this->pricingEngine->calculate($service, $variation, $quantity, (string) Config::get('zone_id'), $provider, $area, now(), max($basic, $campaign), $answers);
            $cart = Cart::where('customer_id', $this->customerUserId)->where('service_id', $service->id)
                ->where('variant_key', $variation->variant_key)->where('provider_id', $provider)->where('branch_service_area_id', $area)
                ->lockForUpdate()->get()->first(fn ($item) => ($item->field_answers ?? []) === $answers) ?? new Cart();
            $cart->forceFill(['customer_id' => $this->customerUserId, 'provider_id' => $provider, 'service_id' => $service->id,
                'variant_key' => $variation->variant_key, 'branch_service_area_id' => $area, 'quantity' => $quantity,
                'field_answers' => $answers, 'execution_snapshot' => $pricing->execution,
                'service_cost' => round($pricing->adjustedPrice / $quantity, 3), 'discount_amount' => $basic > $campaign ? $basic : 0,
                'campaign_discount' => $campaign >= $basic ? $campaign : 0, 'coupon_discount' => 0, 'coupon_code' => null, 'coupon_id' => null,
                'is_guest' => !$this->isCustomerLoggedIn, 'tax_amount' => $pricing->tax, 'total_cost' => $pricing->total,
                'pricing_snapshot' => $pricing->jsonSerialize()])->save();
            $this->addedToCartUpdate($this->customerUserId, $service->id, !$this->isCustomerLoggedIn);
            return response()->json(response_formatter(DEFAULT_STORE_200, $cart));
        });
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function list(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'limit' => 'required|numeric|min:1|max:200',
            'offset' => 'required|numeric|min:1|max:100000',
            'guest_id' => $this->isCustomerLoggedIn ? 'nullable' : 'required|uuid',
        ]);

        if ($validator->fails()) {
            return response()->json(response_formatter(DEFAULT_400, null, error_processor($validator)), 400);
        }

        $customerUserId = $this->customerUserId;
        $cart = $this->cart
            ->with(['customer', 'provider.owner', 'service'])
            ->where(['customer_id' => $customerUserId])
            ->latest()
            ->paginate($request['limit'], ['*'], 'offset', $request['offset'])
            ->withPath('');

        $walletBalance = $this->user->find($customerUserId)?->wallet_balance ?? 0;

        $additionalCharge = 0;
        if ((business_config('booking_additional_charge', 'booking_setup'))?->live_values) {
            $additionalCharge = (business_config('additional_charge_fee_amount', 'booking_setup'))?->live_values;
        }

        foreach ($cart as $cartItem) {
            if ($cartItem?->coupon_code && $cartItem?->coupon_id) {
                $coupon = $this->coupon->where('id', $cartItem->coupon_id)->with('discount')->first();
                // Do not dereference a deleted/inactive coupon relationship on GET cart.
                // Checkout has its own authoritative coupon revalidation.
                if (!$coupon?->discount) {
                    $cartItem['used_count'] = 0;
                    $cartItem['remaining_uses'] = 0;
                } else {
                    $repeatCount = $this->booking->where('customer_id', $this->customerUserId)
                    ->where('coupon_code', $coupon['coupon_code'])
                    ->get()
                    ->sum(function ($booking) use ($coupon) {
                        $repeatCount = $booking->repeat()
                            ->where('coupon_code', $coupon['coupon_code'])
                            ->count();

                        return $repeatCount > 0 ? $repeatCount : 1;
                    });
                    $cartItem['used_count'] = $repeatCount;
                    $cartItem['remaining_uses'] = max(0, $coupon->discount->limit_per_user - $repeatCount);
                }
            }
            if ($cartItem?->provider) {
                $providerId = optional($cartItem->provider)->id;
                $timeSchedule = provider_config('time_schedule', 'service_schedule', $providerId)->live_values ?? '';
                $weekEnds = provider_config('weekends', 'service_schedule', $providerId)->live_values ?? '';
                $weekEnds = json_decode($weekEnds);
                $timeSchedule = json_decode($timeSchedule);
                $serviceLocation = provider_config('service_location', 'provider_config', $providerId)->live_values ?? '';
                $serviceLocations = json_decode($serviceLocation);
                $cartItem->provider->weekends = $weekEnds ?? [];
                $cartItem->provider->service_locations = $serviceLocations ?? [];
                $cartItem->provider->time_schedule = $timeSchedule ?? null;
                $cartItem->provider->nextBookingEligibility = nextBookingEligibility($providerId);
                $cartItem->provider->scheduleBookingEligibility = scheduleBookingEligibility($providerId);

            }
        }

        $totalTax = $cart->sum('tax_amount');
        $totalCost = $cart->sum('total_cost');

        $referralAmount = $this->referralEarningEligiblityCheck($customerUserId, $totalCost - $totalTax);

        $totalCost -= $referralAmount;

        $proBenefitBase = $totalCost - $totalTax;
        $proBenefitType = \Modules\CustomerSubscriptionModule\Lib\ProMemberBenefit::activeBenefitType($customerUserId);
        $proDiscount = \Modules\CustomerSubscriptionModule\Lib\ProMemberBenefit::discountAmount($customerUserId, $proBenefitBase);
        $serviceCharge = \Modules\CustomerSubscriptionModule\Lib\ProMemberBenefit::serviceFee($customerUserId, (float)$additionalCharge, $proBenefitBase);

        $totalCost += $serviceCharge['amount'];
        $totalCost -= $proDiscount;

        if ($proDiscount > 0) {
            $taxableBase = $cart->sum('total_cost') - $cart->sum('tax_amount');
            $proDiscountedTax = 0;
            foreach ($cart as $cartItem) {
                $reducedTax = discounted_tax_amount($cartItem->tax_amount, $taxableBase, $proDiscount);
                $cartItem->total_cost = round($cartItem->total_cost - ($cartItem->tax_amount - $reducedTax), 2);
                $cartItem->tax_amount = $reducedTax;
                $proDiscountedTax += $reducedTax;
            }
            $totalCost -= ($totalTax - $proDiscountedTax);
        }

        $couponDiscountTotal = round($cart->sum('coupon_discount'), 2);

        if ($proBenefitType === 'coupon') {
            $appliedCouponCode = $cart->pluck('coupon_code')->filter()->first();
            $isProCoupon = $appliedCouponCode && Coupon::where('coupon_code', $appliedCouponCode)->where('coupon_type', 'pro_member')->exists();
            $proDiscountAmount = ($isProCoupon && $couponDiscountTotal > 0) ? $couponDiscountTotal : null;
        } elseif ($proBenefitType === 'service_fee') {
            $proDiscountAmount = $serviceCharge['discount'];
        } else {
            $proDiscountAmount = $proDiscount;
        }

        return response()->json(response_formatter(DEFAULT_200, ['total_cost' => $totalCost, 'referral_amount' => $referralAmount, 'pro_benefit_type' => $proBenefitType, 'pro_discount_amount' => $proDiscountAmount, 'service_charge' => $serviceCharge, 'wallet_balance' => with_decimal_point($walletBalance), 'cart' => $cart]), 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param string $id
     * @return JsonResponse
     */
    public function updateQty(Request $request, string $id): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'guest_id' => $this->isCustomerLoggedIn ? 'nullable' : 'required|uuid',
            'quantity' => 'required|integer|min:1|max:1000'
        ]);

        if ($validator->fails()) {
            return response()->json(response_formatter(DEFAULT_400, null, error_processor($validator)), 400);
        }

        Cart::where('customer_id', $this->customerUserId)->findOrFail($id);
        abort_unless($this->updateCartQuantity($id, $request['quantity']), 422, 'service_unavailable');

        $customerUserId = $this->customerUserId;
        $cart = $this->cart
            ->with(['customer', 'provider.owner', 'service'])
            ->where(['customer_id' => $customerUserId])
            ->latest()
            ->paginate(100, ['*'], 'offset', 1)
            ->withPath('');

        foreach ($cart as $item) {
            if ($item->provider) {
                $providerId = $item->provider->id;
                $timeSchedule = provider_config('time_schedule', 'service_schedule', $providerId)->live_values ?? '';
                $weekEnds = provider_config('weekends', 'service_schedule', $providerId)->live_values ?? '';
                $weekEnds = json_decode($weekEnds);
                $timeSchedule = json_decode($timeSchedule);
                $item->provider->weekends = $weekEnds ?? [];
                $item->provider->time_schedule = $timeSchedule ?? null;
                $item->provider->nextBookingEligibility = nextBookingEligibility($providerId);
                $item->provider->scheduleBookingEligibility = scheduleBookingEligibility($providerId);
            }
        }

        $additionalCharge = 0;
        if ((business_config('booking_additional_charge', 'booking_setup'))?->live_values) {
            $additionalCharge = (business_config('additional_charge_fee_amount', 'booking_setup'))?->live_values;
        }
        $totalCost = $cart->sum('total_cost');
        $totalTax = $cart->sum('tax_amount');

        $referralAmount = $this->referralEarningEligiblityCheck($customerUserId, $totalCost - $totalTax);

        $totalCost -= $referralAmount;
        $totalCost += $additionalCharge;

        $walletBalance = $this->user->find($customerUserId)?->wallet_balance ?? 0;

        return response()->json(response_formatter(DEFAULT_UPDATE_200, ['total_cost' => $totalCost,'referral_amount' => $referralAmount, 'wallet_balance' => with_decimal_point($walletBalance), 'cart' => $cart]), 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @return JsonResponse
     */
    public function updateProvider(Request $request): JsonResponse
    {
        $data = $request->validate(['provider_id' => 'nullable|uuid', 'checkout_cart_ids'=>'sometimes|array|min:1|max:100','checkout_cart_ids.*'=>'required|uuid|distinct']);
        $provider = $data['provider_id'] ?? null;
        DB::transaction(function () use ($provider, $data): void {
            $items = Cart::where('customer_id', $this->customerUserId)->when(isset($data['checkout_cart_ids']), fn ($q) => $q->whereIn('id',$data['checkout_cart_ids']))->lockForUpdate()->get();
            abort_if(isset($data['checkout_cart_ids']) && $items->count() !== count($data['checkout_cart_ids']),422,'checkout_cart_item_not_owned');
            if ($provider) {
                $branch = Provider::withoutGlobalScopes()->find($provider);
                abort_unless($branch && (string) $branch->zone_id === (string) Config::get('zone_id')
                    && app(\Modules\ServiceManagement\Services\DirectServicePolicy::class)
                        ->allAvailable($provider, $items->pluck('service_id')->unique()->all()),
                    422, 'no_branch_for_all_services_split_required');
            }
            foreach ($items as $item) {
                $item->forceFill(['provider_id' => $provider, 'branch_service_area_id' => null])->save();
                abort_unless($this->updateCartQuantity($item->id, $item->quantity), 422, 'service_unavailable');
            }
        });
        return response()->json(response_formatter(DEFAULT_UPDATE_200));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param string $id
     * @return JsonResponse
     */
    public function remove(Request $request, string $id): JsonResponse
    {
        $cart = $this->cart->where('customer_id', $this->customerUserId)->whereKey($id)->first();

        if (!isset($cart)) {
            return response()->json(response_formatter(DEFAULT_204), 204);
        }

        $this->cart->where('id', $id)->delete();

        return response()->json(response_formatter(DEFAULT_DELETE_200), 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @return JsonResponse
     */
    public function emptyCart(Request $request): JsonResponse
    {
        $cart = $this->cart->where(['customer_id' => $this->customerUserId]);
        if ($cart->count() == 0) return response()->json(response_formatter(DEFAULT_204), 204);
        $cart->delete();

        return response()->json(response_formatter(DEFAULT_DELETE_200), 200);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function rebookAddToCart(Request $request): JsonResponse
    {
        $request->validate(['booking_id' => 'required|uuid', 'guest_id' => $this->isCustomerLoggedIn ? 'nullable' : 'required|uuid']);
        abort_unless((int) business_config('rebooking_status', 'booking_setup')?->live_values, 403);
        $booking = Booking::where('customer_id', $this->customerUserId)->with('detail')->findOrFail($request->booking_id);
        abort_if($booking->detail->isEmpty(), 422, 'booking_has_no_services');
        DB::transaction(function () use ($booking, $request): void {
            foreach ($booking->detail as $detail) {
                $input = clone $request;
                $input->replace(['service_id' => $detail->service_id, 'variant_key' => $detail->variant_key,
                    'quantity' => $detail->quantity, 'field_answers' => $detail->field_answers ?? [], 'guest_id' => $request->guest_id]);
                $this->addToCart($input); // One transaction; no missing service is silently skipped.
            }
        });
        return response()->json(response_formatter(DEFAULT_CART_STORE_200));
    }


}
