<?php

namespace Modules\PaymentModule\Http\Controllers;

use Illuminate\Contracts\Foundation\Application;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Routing\Redirector;
use Illuminate\Validation\ValidationException;
use Modules\BookingModule\Entities\Booking;
use Modules\BookingModule\Entities\BookingRepeat;
use Modules\CustomerModule\Traits\CustomerAddressTrait;
use Illuminate\Support\Facades\Validator;
use Modules\PaymentModule\Traits\PaymentHelperTrait;
use Modules\ProviderManagement\Entities\Provider;
use Modules\UserManagement\Entities\User;
use Modules\UserManagement\Entities\UserAddress;
use Modules\PaymentModule\Traits\Payment as PaymentTrait;
use Modules\PaymentModule\Library\Payment as Payment;
use Modules\PaymentModule\Library\Payer;
use Modules\PaymentModule\Library\Receiver;


class PaymentController extends Controller
{
    use CustomerAddressTrait, PaymentHelperTrait;

    /**
     * @param Request $request
     * @return JsonResponse|Redirector|RedirectResponse|Application
     * @throws ValidationException
     */
    public function create(Request $request): JsonResponse|Redirector|RedirectResponse|Application
    {
        if (nirab_branch_mode() && $request->has('is_pay_to_admin')) {
            if ($request->expectsJson()) {
                return response()->json(response_formatter(DEFAULT_403, null, [[
                    'error_code' => 'branch_mode_seller_settlement_disabled',
                    'message' => translate('Seller settlement is unavailable in branch mode'),
                ]]), 403);
            }

            return redirect()->route('provider.dashboard')
                ->with('warning', translate('Seller settlement is unavailable in branch mode'));
        }

        if(!is_null($request['is_add_fund']) && !$request->has('is_pay_to_admin')) {
            $validator = Validator::make($request->all(), [
                'amount' => 'required|numeric|gt:0|decimal:0,2',
                'payment_method' => 'required|in:' . implode(',', array_column(GATEWAYS_PAYMENT_METHODS, 'key')),
                'payment_platform' => 'nullable|in:web,app'
            ]);

        }  elseif ($request->has('is_pay_to_admin')) {
            $validator_data = Validator::make($request->all(), [
                'payment_method' => 'required|in:' . implode(',', array_column(GATEWAYS_PAYMENT_METHODS, 'key')),
                'provider_id' => 'required|uuid',
            ]);

        } elseif ($request->has('is_repeat_single_booking')) {
            $validator = Validator::make($request->all(), [
                'payment_method' => 'required|in:' . implode(',', array_column(GATEWAYS_PAYMENT_METHODS, 'key')),
                'payment_platform' => 'nullable|in:web,app',
                'booking_repeat_id' => 'required|uuid',
            ]);
        } elseif ($request->has('switch_offline_to_digital')) {
            $validator = Validator::make($request->all(), [
                'payment_method' => 'required|in:' . implode(',', array_column(GATEWAYS_PAYMENT_METHODS, 'key')),
                'payment_platform' => 'nullable|in:web,app',
                'booking_id' => 'required|uuid',
            ]);
        } elseif ($request->has('switch_cod_to_digital')) {
            $validator = Validator::make($request->all(), [
                'payment_method' => 'required|in:' . implode(',', array_column(GATEWAYS_PAYMENT_METHODS, 'key')),
                'payment_platform' => 'nullable|in:web,app',
                'booking_id' => 'required|uuid',
            ]);
        }else {
            $serviceAtProviderPlace = (int)((business_config('service_at_provider_place', 'provider_config'))->live_values ?? 0);

            $validator = Validator::make($request->all(), [
                'zone_id' => 'required|uuid',
                'service_schedule' => 'required_unless:service_type,repeat|nullable|date',
                'service_address_id' => is_null($request['service_address']) ? 'required' : 'nullable',
                'service_address' => is_null($request['service_address_id']) ? 'required' : 'nullable',
                'payment_method' => 'required|in:' . implode(',', array_column(GATEWAYS_PAYMENT_METHODS, 'key')),
                'callback' => 'nullable',
                //For bidding
                'post_id' => 'nullable|uuid',
                'quotation_id' => 'nullable|uuid',
                'quotation_payable_amount' => 'nullable|numeric|min:0',
                'provider_id' => 'nullable|uuid',
                'branch_selection' => 'nullable|in:manual,auto',
                'checkout_snapshot_id' => 'nullable|uuid', 'service_type' => 'nullable|in:regular,repeat',
                'booking_type' => 'nullable|in:daily,weekly,custom', 'dates' => 'nullable|json',
                'is_partial' => 'nullable|in:0,1',
                'payment_platform' => 'nullable|in:web,app',
                'service_location' => ['required', 'in:customer,provider',
                function ($attribute, $value, $fail) use ($serviceAtProviderPlace) {
                    if ($value == 'provider' && $serviceAtProviderPlace != 1) {
                        $fail('The selected service location cannot be "provider" because the service is not available at the provider’s place.');
                    }
                }],
            ]);
        }

        if ($request->has('is_pay_to_admin')){
            if ($validator_data->fails()) {
                return redirect()->back()->withErrors($validator_data);
            }

            $provider = Provider::where('id', $request['provider_id'])->first();

            if ($provider){
                $amount = $provider->owner->account->account_payable - $provider->owner->account->account_receivable;
                $minPayableAmount = business_config('min_payable_amount', 'provider_config')->live_values ?? 0;
                if ($minPayableAmount > 0 && $amount < $minPayableAmount){
                    return redirect()->back()->withErrors(translate('Provider must have to pay greater than or equal to ') . $minPayableAmount);
                }
            }

        }else{
            if ($validator->fails()) {
                return response()->json(response_formatter(DEFAULT_400, null, error_processor($validator)), 400);
            }
        }

        $principal = $request->attributes->get('payment_principal');
        abort_unless(is_array($principal) && isset($principal['id'], $principal['is_guest']), 401);
        $customer_user_id = $principal['id'];
        $is_guest = $principal['is_guest'];
        $is_add_fund = $request->boolean('is_add_fund');
        $is_pay_to_admin = false;
        $is_repeat_single_booking = $request->boolean('is_repeat_single_booking');
        $switch_offline_to_digital = $request->boolean('switch_offline_to_digital');
        $switch_cod_to_digital = $request->boolean('switch_cod_to_digital');
        abort_if(array_sum([$is_add_fund, $is_repeat_single_booking, $switch_offline_to_digital, $switch_cod_to_digital]) > 1, 422);

        //==========>>>>>> IF ADD FUND <<<<<<<==============

        //add fund
        if ($is_add_fund) {
            $customer = User::find($customer_user_id);
            $payer = new Payer($customer['first_name'] . ' ' . $customer['last_name'], $customer['email'], $customer['phone'], '');
            $payment_info = new Payment(
                success_hook: 'add_fund_success',
                failure_hook: 'add_fund_fail',
                currency_code: currency_code(),
                payment_method: $request['payment_method'],
                payment_platform: $request['payment_platform'],
                payer_id: $customer_user_id,
                receiver_id: null,
                additional_data: $validator->validated(),
                payment_amount: $request['amount'],
                external_redirect_link: $request['callback'] ?? null,
                attribute: 'booking_id',
                attribute_id: time()
            );

            $receiver_info = new Receiver('receiver_name', 'example.png');
            $redirect_link = PaymentTrait::generate_link($payer, $payment_info, $receiver_info);
            return redirect($redirect_link);
        }

        //==========>>>>>> IF Provider to Admin Pay <<<<<<<==============

        if ($is_pay_to_admin) {

            $provider = Provider::where('id', $request['provider_id'])->first();

            if ($provider) {
                $customer = User::find($provider->user_id);
                if ($provider->owner->account->account_payable > $provider->owner->account->account_receivable) {
                    $amount = $provider->owner->account->account_payable - $provider->owner->account->account_receivable;
                    $payer = new Payer($customer['first_name'] . ' ' . $customer['last_name'], $customer['email'], $customer['phone'], '');
                    $additional_data = ['provider_id'=> $request['provider_id']];

                    $payment_info = new Payment(
                        success_hook: 'pay_to_admin_success',
                        failure_hook: 'pay_to_admin_fail',
                        currency_code: currency_code(),
                        payment_method: $request['payment_method'],
                        payment_platform: 'web',
                        payer_id: $customer['id'],
                        receiver_id: null,
                        additional_data: $additional_data,
                        payment_amount: $amount,
                        external_redirect_link: route('provider.account_info'),
                        attribute: 'booking_id',
                        attribute_id: time()
                    );

                    $receiver_info = new Receiver('receiver_name', 'example.png');
                    $redirect_link = PaymentTrait::generate_link($payer, $payment_info, $receiver_info);
                    return redirect($redirect_link);
                } else {
                    return redirect()->back()->withErrors(translate('Invalid Amount'));
                }
            } else {
                return redirect()->back()->withErrors(translate('Provider Not Found'));
            }

        }

        if ($is_repeat_single_booking || $switch_offline_to_digital || $switch_cod_to_digital) {
            $state = app(\Modules\PaymentModule\Services\ExistingBookingPayment::class)->prepare($customer_user_id, $request->all());
            $additional = $request->only(['booking_repeat_id', 'booking_id', 'switch_offline_to_digital', 'switch_cod_to_digital', 'payment_method', 'callback']);
            $additional += ['wallet_paid_amount' => $state['wallet'], 'debt_snapshot' => $state['debt_snapshot']];
            $request->attributes->set('payment_debt', $state);
            $customer = User::find($customer_user_id);
            $payer = new Payer($customer?->first_name ?? 'NIRAB', $customer?->email ?? '', $customer?->phone ?? '', '');
            $hook = $is_repeat_single_booking ? 'repeat_booking_payment' : ($switch_offline_to_digital ? 'switch_offline_to_digital_payment' : 'switch_cod_to_digital_payment');
            $payment_info = new Payment(success_hook: $hook . '_success', failure_hook: $hook . '_fail',
                currency_code: currency_code(), payment_method: $request->payment_method, payment_platform: $request->input('payment_platform', 'app'),
                payer_id: $customer_user_id, receiver_id: null, additional_data: $additional, payment_amount: $state['amount'],
                external_redirect_link: $request->input('callback'), attribute: 'booking', attribute_id: $state['subject']->readable_id);
            return redirect(PaymentTrait::generate_link($payer, $payment_info, new Receiver('receiver_name', 'example.png')));
        }

        //==========>>>>>> IF Booking <<<<<<<==============

        //service address create (if no saved address)
        if ($request->filled('service_address_id')) {
            $saved = UserAddress::where('user_id', $customer_user_id)->findOrFail($request->service_address_id);
            $service_address = (object) $saved->getAttributes();
        } else {
            $service_address = json_decode(base64_decode((string) $request['service_address'], true));
        }
        if (!collect($service_address)->has(['lat', 'lon', 'address', 'contact_person_name', 'contact_person_number', 'address_label'])) {
            if ($request->has('callback')) return redirect($request['callback'] . '?flag=fail');
            else return response()->json(response_formatter(DEFAULT_400), 400);
        }
        if (is_null($request['service_address_id']) && !nirab_branch_mode()) {
            $request['service_address_id'] = $this->add_address($service_address, $customer_user_id, $is_guest);
        }
        if (is_null($request['service_address_id']) && !nirab_branch_mode()) {
            if ($request->has('callback')) return redirect($request['callback'] . '?flag=fail');
            else return response()->json(response_formatter(DEFAULT_400), 400);
        }

        // Register new user from guest info
        $newUserInfo = json_decode(base64_decode((string) $request['new_user_info'], true), true);
        if ($newUserInfo) {
            abort_unless($is_guest, 422);
            $newUserInfo = Validator::make($newUserInfo, ['first_name' => 'required|string|max:100',
                'phone' => 'required|string|max:30|unique:users,phone', 'password' => 'required|string|min:8|max:200'])->validate();
        }

        if($newUserInfo != null){
            $new_data = [
                'register_new_customer' => 1
            ];
            $query_params = array_merge($validator->validated(), ['service_address_id' => $request['service_address_id']], $new_data);
            $query_params['registration_ciphertext'] = \Illuminate\Support\Facades\Crypt::encryptString(json_encode($newUserInfo));
        }else{
            $query_params = array_merge($validator->validated(), ['service_address_id' => $request['service_address_id']]);
        }

        //guest user check
        if ($is_guest) {
            $address = $request['service_address_id'] ? UserAddress::find($request['service_address_id']) : (array) $service_address;
            $customer = collect([
                'first_name' => $address['contact_person_name'],
                'last_name' => '',
                'phone' => $address['contact_person_number'],
                'email' => '',
            ]);

        } else {
            $customer = User::find($customer_user_id);
            $customer = collect([
                'first_name' => $customer['first_name'],
                'last_name' => $customer['last_name'],
                'phone' => $customer['phone'],
                'email' => $customer['email'],
            ]);
        }
        $query_params['customer'] = base64_encode($customer);

        if (nirab_branch_mode() && !$request->filled('post_id')) {
            $query_params['service_address'] = json_encode($service_address);
            $query_params['service_type'] = $request->input('service_type', 'regular');
            $snapshot = app(\Modules\BookingModule\Services\BranchCheckoutService::class)->approved((string) $customer_user_id, $query_params);
            $total_booking_amount = $snapshot->payload['total'];
        } else {
            $total_booking_amount = $this->find_total_Booking_amount($customer_user_id, $request['post_id'], $request['provider_id'], $request->quotation_id);
        }
        $customer_wallet_balance = User::find($customer_user_id)?->wallet_balance;
        $walletAmount = isset($snapshot) ? $snapshot->payload['wallet_amount'] : ($request['is_partial'] ? floor((float) $customer_wallet_balance * 100) / 100 : 0);
        $amount_to_pay = round($total_booking_amount - $walletAmount, 2);
        if (nirab_branch_mode()) {
            $query_params['wallet_paid_amount'] = isset($snapshot) ? $snapshot->payload['wallet_amount'] : ($request['is_partial'] ? floor((float) $customer_wallet_balance * 100) / 100 : 0);
        }

        //partial validation
        if (!$is_guest && $request['is_partial'] && ($customer_wallet_balance <= 0 || $customer_wallet_balance >= $total_booking_amount)) {
            return response()->json(response_formatter(DEFAULT_400), 400);
        }

        //make payment
        $payer = new Payer($customer['first_name'] . ' ' . $customer['last_name'], $customer['email'], $customer['phone'], '');
        $payment_info = new Payment(
            success_hook: 'digital_payment_success',
            failure_hook: 'digital_payment_fail',
            currency_code: currency_code(),
            payment_method: $request->payment_method,
            payment_platform: $request->payment_platform,
            payer_id: $customer_user_id,
            receiver_id: null,
            additional_data: $query_params,
            payment_amount: $amount_to_pay,
            external_redirect_link: $request['callback'] ?? null,
            attribute: 'booking_id',
            attribute_id: time()
        );

        $receiver_info = new Receiver('receiver_name', 'example.png');
        $redirect_link = PaymentTrait::generate_link($payer, $payment_info, $receiver_info);
        return redirect($redirect_link);
    }

    /**
     * @param Request $request
     * @return JsonResponse|Redirector|RedirectResponse|Application
     */
    public function success(Request $request): JsonResponse|Redirector|RedirectResponse|Application
    {
        if (isset($request['callback'])) return redirect($request['callback'] . '?flag=success');
        else return response()->json(response_formatter(DEFAULT_200), 200);
    }

    /**
     * @param Request $request
     * @return JsonResponse|Redirector|RedirectResponse|Application
     */
    public function fail(Request $request): JsonResponse|Redirector|RedirectResponse|Application
    {
        if ($request->has('callback')) return redirect($request['callback'] . '?flag=fail');
        else return response()->json(response_formatter(DEFAULT_400), 400);
    }
}
