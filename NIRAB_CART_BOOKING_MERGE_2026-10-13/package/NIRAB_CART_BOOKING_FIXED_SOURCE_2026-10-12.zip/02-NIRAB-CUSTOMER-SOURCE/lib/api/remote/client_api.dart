import 'dart:convert';
import 'package:demandium/common/models/errrors_model.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import 'package:demandium/util/core_export.dart';
import 'package:path/path.dart';

class ApiClient extends GetxService {
  final String? appBaseUrl;
  final SharedPreferences sharedPreferences;
  static final String noInternetMessage = 'connection_to_api_server_failed'.tr;
  final int timeoutInSeconds = 30;

  String? token;
  late Map<String, String> _mainHeaders;
  final ValueNotifier<int> marketingRevision = ValueNotifier(0);
  bool _headersInitialized = false;
  bool get hasMarketingZone {
    final zone = (_mainHeaders[AppConstants.zoneId] ?? '').trim();
    if (zone.isEmpty || zone == 'null') return false;
    if (zone.startsWith('[')) {
      try {
        return (jsonDecode(zone) as List).any(
          (id) => id is String && id.trim().isNotEmpty,
        );
      } catch (_) {
        return false;
      }
    }
    return true;
  }

  ApiClient({required this.appBaseUrl, required this.sharedPreferences}) {
    token = sharedPreferences.getString(AppConstants.token);

    AddressModel? addressModel;
    try {
      addressModel = AddressModel.fromJson(
        jsonDecode(sharedPreferences.getString(AppConstants.userAddress)!),
      );
    } catch (e) {
      if (kDebugMode) {
        print('');
      }
    }

    ///pick zone id to update header
    updateHeader(
      token,
      addressModel?.zoneId,
      sharedPreferences.getString(AppConstants.languageCode),
      sharedPreferences.getString(AppConstants.guestId),
    );
  }
  void updateHeader(
    String? token,
    String? zoneIDs,
    String? languageCode,
    String? guestID,
  ) {
    final changed =
        _headersInitialized &&
        (_mainHeaders[AppConstants.zoneId] != (zoneIDs ?? '') ||
            _mainHeaders[AppConstants.localizationKey] !=
                (languageCode ?? AppConstants.languages[0].languageCode!) ||
            _mainHeaders['Authorization'] != 'Bearer $token' ||
            _mainHeaders[AppConstants.guestId] != (guestID ?? ''));
    _mainHeaders = {
      'Content-Type': 'application/json; charset=UTF-8',
      'Accept': 'application/json',
      AppConstants.zoneId: zoneIDs ?? '',
      AppConstants.localizationKey:
          languageCode ?? AppConstants.languages[0].languageCode!,
      'Authorization': 'Bearer $token',
      AppConstants.guestId: guestID ?? "",
    };
    _headersInitialized = true;
    // Opaque revision only: no credential or personal identifier in cache keys.
    if (changed) marketingRevision.value++;
  }

  void updateGuestIdHeader(String guestId) {
    if (_mainHeaders[AppConstants.guestId] == guestId) return;
    _mainHeaders[AppConstants.guestId] = guestId;
    marketingRevision.value++;
  }

  Future<Response> getData(
    String uri, {
    Map<String, dynamic>? query,
    Map<String, String>? headers,
  }) async {
    try {
      http.Response response = await http
          .get(
            Uri.parse(appBaseUrl! + uri),
            headers: {
              ...(headers ?? _mainHeaders),
              'X-Guest-Payment-Token':
                  sharedPreferences.getString('nirab_guest_payment_token') ??
                  '',
            },
          )
          .timeout(Duration(seconds: timeoutInSeconds));

      return handleResponse(response, uri);
    } catch (e) {
      return Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> postData(
    String? uri,
    dynamic body, {
    Map<String, String>? headers,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse(appBaseUrl! + uri!),
            body: jsonEncode(body),
            headers: {
              ...(headers ?? _mainHeaders),
              'X-Guest-Payment-Token':
                  sharedPreferences.getString('nirab_guest_payment_token') ?? '',
            },
          )
          .timeout(Duration(seconds: timeoutInSeconds));
      return handleResponse(response, uri);
    } catch (e) {
      return Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> postMultipartDataConversation(
    String? uri,
    Map<String, String> body,
    List<MultipartBody>? multipartBody, {
    Map<String, String>? headers,
    List<PlatformFile>? otherFile,
  }) async {
    http.MultipartRequest request = http.MultipartRequest(
      'POST',
      Uri.parse(appBaseUrl! + uri!),
    );
    request.headers.addAll(headers ?? _mainHeaders);

    if (otherFile != null) {
      if (otherFile.isNotEmpty) {
        for (PlatformFile platformFile in otherFile) {
          request.files.add(
            http.MultipartFile(
              'files[${otherFile.indexOf(platformFile)}]',
              platformFile.readStream!,
              platformFile.size,
              filename: basename(platformFile.name),
            ),
          );
        }
      }
    }
    if (multipartBody != null) {
      for (MultipartBody multipart in multipartBody) {
        Uint8List list = await multipart.file.readAsBytes();
        request.files.add(
          http.MultipartFile(
            multipart.key!,
            multipart.file.readAsBytes().asStream(),
            list.length,
            filename: '${DateTime.now().toString()}.png',
          ),
        );
      }
    }
    request.fields.addAll(body);
    http.Response response = await http.Response.fromStream(
      await request.send(),
    );
    return handleResponse(response, uri);
  }

  Future<Response> postMultipartData(
    String? uri,
    Map<String, String> body,
    List<MultipartBody>? multipartBody, {
    Map<String, String>? headers,
    Map<String, String>? additionalData,
  }) async {
    try {
      http.MultipartRequest request = http.MultipartRequest(
        'POST',
        Uri.parse(appBaseUrl! + uri!),
      );
      request.headers.addAll(headers ?? _mainHeaders);
      for (MultipartBody multipart in multipartBody!) {
        if (kIsWeb) {
          Uint8List list = await multipart.file.readAsBytes();
          http.MultipartFile part = http.MultipartFile(
            multipart.key!,
            multipart.file.readAsBytes().asStream(),
            list.length,
            filename: multipart.file.name,
          );
          request.files.add(part);
        } else {
          File file = File(multipart.file.path);
          request.files.add(
            http.MultipartFile(
              multipart.key!,
              file.readAsBytes().asStream(),
              file.lengthSync(),
              filename: file.path.split('/').last,
            ),
          );
        }
      }
      request.fields.addAll(body);

      if (additionalData != null) {
        request.fields.addAll(additionalData);
      }

      http.Response response = await http.Response.fromStream(
        await request.send(),
      );
      return handleResponse(response, uri);
    } catch (e) {
      return Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> putData(
    String? uri,
    dynamic body, {
    Map<String, String>? headers,
  }) async {
    try {
      http.Response response = await http
          .put(
            Uri.parse(appBaseUrl! + uri!),
            body: jsonEncode(body),
            headers: {
              ...(headers ?? _mainHeaders),
              'X-Guest-Payment-Token':
                  sharedPreferences.getString('nirab_guest_payment_token') ??
                  '',
            },
          )
          .timeout(Duration(seconds: timeoutInSeconds));
      return handleResponse(response, uri);
    } catch (e) {
      return Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> deleteData(
    String? uri, {
    Map<String, String>? headers,
  }) async {
    try {
      http.Response response = await http
          .delete(
            Uri.parse(appBaseUrl! + uri!),
            headers: {
              ...(headers ?? _mainHeaders),
              'X-Guest-Payment-Token':
                  sharedPreferences.getString('nirab_guest_payment_token') ??
                  '',
            },
          )
          .timeout(Duration(seconds: timeoutInSeconds));
      return handleResponse(response, uri);
    } catch (e) {
      return Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Response handleResponse(http.Response response, String? uri) {
    dynamic body;
    try {
      body = jsonDecode(response.body);
    } catch (e) {
      if (kDebugMode) {
        print("");
      }
    }
    Response response0 = Response(
      body: body ?? response.body,
      bodyString: response.body.toString(),
      request: Request(
        headers: response.request!.headers,
        method: response.request!.method,
        url: response.request!.url,
      ),
      headers: response.headers,
      statusCode: response.statusCode,
      statusText: response.reasonPhrase,
    );
    if (response0.statusCode != 200 &&
        response0.body != null &&
        response0.body is! String) {
      if (response0.body.toString().startsWith('{response_code:')) {
        ErrorsModel errorResponse = ErrorsModel.fromJson(response0.body);
        response0 = Response(
          statusCode: response0.statusCode,
          body: response0.body,
          statusText: errorResponse.responseCode,
        );
      } else if (response0.body.toString().startsWith('{message')) {
        response0 = Response(
          statusCode: response0.statusCode,
          body: response0.body,
          statusText: response0.body['message'],
        );
      }
    } else if (response0.statusCode != 200 && response0.statusCode != 204 && response0.body == null) {
      response0 = Response(statusCode: 0, statusText: noInternetMessage);
    }
    return response0;
  }
}

class MultipartBody {
  String? key;
  XFile file;

  MultipartBody(this.key, this.file);
}
