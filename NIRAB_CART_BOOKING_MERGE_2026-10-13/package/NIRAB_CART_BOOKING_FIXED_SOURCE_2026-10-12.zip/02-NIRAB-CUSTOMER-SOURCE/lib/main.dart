import 'package:demandium/feature/home/marketing/marketing_lifecycle.dart';
import 'dart:convert';
import 'package:demandium/common/widgets/nirab/nirab_icon.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get.dart';
import 'package:demandium/theme/brand_typography.dart';
import 'package:universal_html/html.dart' as html;
import 'package:url_strategy/url_strategy.dart';
import 'helper/analytics/analytics_helper.dart';
import 'util/core_export.dart';
import 'helper/get_di.dart' as di;

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  registerSolarIconLicense();
  if (ResponsiveHelper.isMobilePhone()) {
    await FlutterDownloader.initialize();
  }
  setPathUrlStrategy();
  AnalyticsHelper.init();

  try {
    if (kIsWeb) {
      await Firebase.initializeApp(
        options: const FirebaseOptions(
          apiKey: "AIzaSyAMm4hm0sgctMNPHL0ZZ8R3gjJTK9D5bGw",
          authDomain: "nirab-production.firebaseapp.com",
          projectId: "nirab-production",
          storageBucket: "nirab-production.firebasestorage.app",
          messagingSenderId: "904380048518",
          appId: "1:904380048518:web:067279f98e823c00295d07",
          measurementId: "G-XZMZ19P0JC",
        ),
      );
    } else if (Platform.isAndroid) {
      try {
        await Firebase.initializeApp();
      } catch (e) {
        await Firebase.initializeApp();
      }
    } else {
      await Firebase.initializeApp();
    }
  } catch (e) {
    if (kDebugMode) {
      print('Error initializing Flutter bindings: ${e.toString()}');
    }
  }

  if (kIsWeb) {
    await FacebookAuth.instance.webAndDesktopInitialize(
      appId: "482889663914976",
      cookie: true,
      xfbml: true,
      version: "v15.0",
    );
  }

  if (defaultTargetPlatform == TargetPlatform.android) {
    await FirebaseMessaging.instance.requestPermission();
  }

  Map<String, Map<String, String>> languages = await di.init();
  NotificationBody? body;
  String? path;
  try {
    if (!kIsWeb) {
      path = await initDynamicLinks();
    }

    final RemoteMessage? remoteMessage = await FirebaseMessaging.instance
        .getInitialMessage();
    if (remoteMessage != null) {
      body = NotificationHelper.convertNotification(remoteMessage.data);
    }
    await NotificationHelper.initialize(flutterLocalNotificationsPlugin);
    FirebaseMessaging.onBackgroundMessage(myBackgroundMessageHandler);
  } catch (e) {
    if (kDebugMode) {
      print("");
    }
  }
  runApp(MyApp(languages: languages, body: body, route: path));
}

class MyApp extends StatefulWidget {
  final Map<String, Map<String, String>>? languages;
  final NotificationBody? body;
  final String? route;
  const MyApp({
    super.key,
    required this.languages,
    required this.body,
    this.route,
  });

  @override
  State<MyApp> createState() => _MyAppState();
}

Future<String?> initDynamicLinks() async {
  final appLinks = AppLinks();
  final uri = await appLinks.getInitialLink();
  String? path;
  if (uri != null) {
    path = uri.path;
  } else {
    path = null;
  }
  return path;
}

class _MyAppState extends State<MyApp> {
  bool? _lastWebDark;
  String? _lastWebLanguage;

  void _syncWebAppearance(bool darkTheme, String languageCode) {
    if (!kIsWeb ||
        (_lastWebDark == darkTheme && _lastWebLanguage == languageCode)) {
      return;
    }
    _lastWebDark = darkTheme;
    _lastWebLanguage = languageCode;
    html.window.dispatchEvent(
      html.CustomEvent(
        'nirab-appearance',
        detail: jsonEncode({'dark': darkTheme, 'languageCode': languageCode}),
      ),
    );
  }

  void _route() async {
    Get.find<SplashController>().getConfigData().then((success) async {
      if (Get.find<LocationController>().getUserAddress() != null) {
        AddressModel addressModel = Get.find<LocationController>()
            .getUserAddress()!;
        ZoneResponseModel responseModel = await Get.find<LocationController>()
            .getZone(
              addressModel.latitude.toString(),
              addressModel.longitude.toString(),
              false,
            );
        addressModel.availableServiceCountInZone =
            responseModel.totalServiceCount;
        Get.find<LocationController>().saveUserAddress(addressModel);
      }
      Get.find<AuthController>().updateToken();
    });
  }

  Future<void> _initializeWebCart() async {
    await Get.find<SplashController>().initSharedData();
    if (!Get.find<AuthController>().isLoggedIn()) {
      final ready = await Get.find<SplashRepo>().ensurePaymentGuestSession();
      if (!ready) return;
    }
    if (!mounted) return;
    await Get.find<CartController>().getCartListFromServer();
  }

  @override
  void initState() {
    super.initState();

    if (kIsWeb || widget.route != null) {
      _initializeWebCart();
      Get.find<SplashController>().getCookiesData();
      if (Get.find<AuthController>().isLoggedIn()) {
        Get.find<UserController>().getUserInfo();
      }
      _route();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ThemeController>(
      builder: (themeController) {
        return GetBuilder<LocalizationController>(
          builder: (localizeController) {
            _syncWebAppearance(
              themeController.darkTheme,
              localizeController.locale.languageCode,
            );
            return GetBuilder<SplashController>(
              builder: (splashController) {
                if ((GetPlatform.isWeb &&
                    splashController.configModel.content == null)) {
                  return const SizedBox();
                } else if ((!GetPlatform.isWeb &&
                        !Get.currentRoute.contains('/splash') &&
                        Get.currentRoute.isNotEmpty) &&
                    splashController.configModel.content == null) {
                  return Material(child: SplashLogoWidget());
                } else {
                  return GetMaterialApp(
                    title: AppConstants.appName,
                    debugShowCheckedModeBanner: false,
                    navigatorKey: Get.key,
                    navigatorObservers: [marketingRouteObserver],
                    scrollBehavior: const MaterialScrollBehavior().copyWith(
                      dragDevices: {
                        PointerDeviceKind.mouse,
                        PointerDeviceKind.touch,
                      },
                    ),
                    theme: BrandTypography.applyTheme(
                      themeController.darkTheme ? dark : light,
                      localizeController.locale,
                    ),
                    locale: localizeController.locale,
                    localizationsDelegates:
                        GlobalMaterialLocalizations.delegates,
                    supportedLocales: AppConstants.languages.map(
                      (language) =>
                          Locale(language.languageCode!, language.countryCode),
                    ),
                    translations: Messages(languages: widget.languages),
                    fallbackLocale: Locale(
                      AppConstants.languages[0].languageCode!,
                      AppConstants.languages[0].countryCode,
                    ),
                    initialRoute: GetPlatform.isWeb
                        ? RouteHelper.getInitialRoute()
                        : RouteHelper.getSplashRoute(widget.body, widget.route),
                    getPages: RouteHelper.routes,
                    defaultTransition: Transition.fadeIn,
                    transitionDuration: const Duration(milliseconds: 500),
                    builder: (context, widget) => Material(
                      child: SafeArea(
                        top: false,
                        bottom: GetPlatform.isAndroid,
                        child: widget == null
                            ? const SizedBox()
                            : Stack(
                                children: [
                                  widget,

                                  GetBuilder<SplashController>(
                                    builder: (splashController) {
                                      if (!splashController.savedCookiesData ||
                                          !splashController
                                              .getAcceptCookiesStatus(
                                                splashController
                                                        .configModel
                                                        .content
                                                        ?.cookiesText ??
                                                    "",
                                              )) {
                                        return ResponsiveHelper.isWeb()
                                            ? const Align(
                                                alignment:
                                                    Alignment.bottomCenter,
                                                child: CookiesView(),
                                              )
                                            : const SizedBox();
                                      } else {
                                        return const SizedBox();
                                      }
                                    },
                                  ),
                                ],
                              ),
                      ),
                    ),
                  );
                }
              },
            );
          },
        );
      },
    );
  }
}
