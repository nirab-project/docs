import 'package:demandium/helper/payment_session_helper.dart';
import 'dart:convert';
import 'package:demandium/util/core_export.dart';
import 'package:universal_html/html.dart' as html;
import 'package:get/get.dart';

class ProceedToCheckoutButtonWidget extends StatefulWidget {
  final String pageState;
  final String addressId;
  const ProceedToCheckoutButtonWidget({
    super.key,
    required this.pageState,
    required this.addressId,
  });

  @override
  State<ProceedToCheckoutButtonWidget> createState() =>
      _ProceedToCheckoutButtonWidgetState();
}

class _ProceedToCheckoutButtonWidgetState
    extends State<ProceedToCheckoutButtonWidget> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<ScheduleController>(
      builder: (scheduleController) {
        return GetBuilder<CartController>(
          builder: (cartController) {
            String? errorText = cartController
                .checkScheduleBookingAvailability();
            double totalAmount = cartController.totalPrice;
            bool isPartialPayment = CheckoutHelper.checkPartialPayment(
              walletBalance: cartController.walletBalance,
              bookingAmount: cartController.totalPrice,
            );
            String? schedule = scheduleController.scheduleTime;

            ConfigModel configModel = Get.find<SplashController>().configModel;
            bool isLoggedIn = Get.find<AuthController>().isLoggedIn();
            bool createGuestAccount =
                Get.find<SplashController>()
                    .configModel
                    .content
                    ?.createGuestUserAccount ==
                1;

            return GetBuilder<CheckOutController>(
              builder: (checkoutController) {
                return Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: Dimensions.paddingSizeDefault,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          vertical: Dimensions.paddingSizeSmall,
                        ),
                        child: Center(
                          child: Wrap(
                            alignment: WrapAlignment.center,
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Text(
                                "total_price".tr,
                                style: robotoRegular.copyWith(
                                  fontSize: Dimensions.fontSizeDefault,
                                  color: Theme.of(context).hintColor,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Directionality(
                                textDirection: TextDirection.ltr,
                                child: Text(
                                  PriceConverter.convertPrice(totalAmount),
                                  style: robotoBold.copyWith(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.primary,
                                    fontSize: Dimensions.fontSizeExtraLarge,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      CustomButton(
                        height: 56,
                        radius: Dimensions.radiusDefault,
                        isLoading: checkoutController.isLoading,
                        fontSize: Dimensions.fontSizeDefault + 1,
                        buttonText: cartController.checkoutItems.isEmpty
                            ? "empty_cart_go_back".tr
                            : (widget.pageState == "orderDetails" &&
                                  checkoutController.currentPageState ==
                                      PageState.orderDetails)
                            ? "make_payment".tr
                            : 'confirm_booking'.tr,
                        onPressed:
                            (widget.pageState == "payment" ||
                                    checkoutController.currentPageState ==
                                        PageState.payment) &&
                                checkoutController.othersPaymentList.isEmpty &&
                                checkoutController.digitalPaymentList.isEmpty
                            ? null
                            : () {
                                if (errorText != null &&
                                    scheduleController.selectedScheduleType !=
                                        ScheduleType.asap) {
                                  customSnackBar(errorText.tr);
                                } else if (checkoutController.acceptTerms ||
                                    cartController.checkoutItems.isEmpty) {
                                  AddressModel? addressModel =
                                      CheckoutHelper.selectedAddressModel(
                                        selectedAddress:
                                            Get.find<LocationController>()
                                                .selectedAddress,
                                        pickedAddress:
                                            Get.find<LocationController>()
                                                .getUserAddress(),
                                        selectedLocationType:
                                            Get.find<LocationController>()
                                                .selectedServiceLocationType,
                                      );
                                  if (Get.find<CartController>()
                                      .cartList
                                      .isEmpty) {
                                    Get.offAllNamed(
                                      RouteHelper.getMainRoute('home'),
                                    );
                                  } else if (cartController
                                          .cartList
                                          .isNotEmpty &&
                                      cartController
                                              .checkoutItems
                                              .first
                                              .provider !=
                                          null &&
                                      (cartController
                                                  .cartList[0]
                                                  .provider
                                                  ?.serviceAvailability ==
                                              0 ||
                                          cartController
                                                  .cartList[0]
                                                  .provider
                                                  ?.isActive ==
                                              0)) {
                                    Future.delayed(
                                      const Duration(milliseconds: 50),
                                    ).then((value) {
                                      Future.delayed(
                                        const Duration(milliseconds: 500),
                                      ).then((value) {
                                        showModalBottomSheet(
                                          useRootNavigator: true,
                                          isScrollControlled: true,
                                          backgroundColor: Colors.transparent,
                                          context: Get.context!,
                                          builder: (context) =>
                                              AvailableProviderWidget(
                                                showUnavailableError: true,
                                              ),
                                        );
                                      });

                                      customSnackBar(
                                        "your_selected_provider_is_unavailable_right_now"
                                            .tr,
                                        duration: 3,
                                        type: ToasterMessageType.info,
                                      );
                                    });
                                  } else if (checkoutController
                                              .currentPageState ==
                                          PageState.orderDetails &&
                                      PageState.orderDetails.name ==
                                          widget.pageState) {
                                    if (schedule == null &&
                                        scheduleController
                                                .selectedScheduleType !=
                                            ScheduleType.asap &&
                                        scheduleController.selectedServiceType ==
                                            ServiceType.regular) {
                                      customSnackBar(
                                        "select_your_preferable_booking_time"
                                            .tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (scheduleController
                                                .selectedScheduleType ==
                                            ScheduleType.schedule &&
                                        configModel
                                                .content
                                                ?.scheduleBookingTimeRestriction ==
                                            1 &&
                                        scheduleController
                                                .checkValidityOfTimeRestriction(
                                                  Get.find<SplashController>()
                                                      .configModel
                                                      .content!
                                                      .advanceBooking!,
                                                ) !=
                                            null &&
                                        scheduleController.selectedServiceType ==
                                            ServiceType.regular) {
                                      customSnackBar(
                                        scheduleController
                                            .checkValidityOfTimeRestriction(
                                              Get.find<SplashController>()
                                                  .configModel
                                                  .content!
                                                  .advanceBooking!,
                                            ),
                                      );
                                    } else if (scheduleController.selectedServiceType ==
                                            ServiceType.repeat &&
                                        scheduleController
                                                .selectedRepeatBookingType ==
                                            RepeatBookingType.daily &&
                                        scheduleController
                                                .pickedDailyRepeatBookingDateRange ==
                                            null) {
                                      customSnackBar(
                                        "daily_select_time_and_date_hint".tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (scheduleController.selectedServiceType ==
                                            ServiceType.repeat &&
                                        scheduleController
                                                .selectedRepeatBookingType ==
                                            RepeatBookingType.daily &&
                                        scheduleController.pickedDailyRepeatTime ==
                                            null) {
                                      customSnackBar(
                                        "select_time_hint".tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (scheduleController
                                                .selectedServiceType ==
                                            ServiceType.repeat &&
                                        scheduleController
                                                .selectedRepeatBookingType ==
                                            RepeatBookingType.weekly &&
                                        scheduleController
                                            .getWeeklyPickedDays()
                                            .isEmpty) {
                                      customSnackBar(
                                        "weekly_select_time_and_date_hint".tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (scheduleController
                                                .selectedServiceType ==
                                            ServiceType.repeat &&
                                        scheduleController
                                                .selectedRepeatBookingType ==
                                            RepeatBookingType.weekly &&
                                        scheduleController.pickedWeeklyRepeatTime ==
                                            null) {
                                      customSnackBar(
                                        "select_time_hint".tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (scheduleController
                                                .selectedServiceType ==
                                            ServiceType.repeat &&
                                        scheduleController
                                                .selectedRepeatBookingType ==
                                            RepeatBookingType.custom &&
                                        scheduleController
                                            .pickedCustomRepeatBookingDateTimeList
                                            .isEmpty) {
                                      customSnackBar(
                                        "custom_select_time_and_date_hint".tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (addressModel == null) {
                                      customSnackBar(
                                        "add_address_first".tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if ((addressModel.contactPersonName ==
                                                "null" ||
                                            addressModel.contactPersonName ==
                                                null ||
                                            addressModel.contactPersonName!.isEmpty) ||
                                        (addressModel.contactPersonNumber == "null" ||
                                            addressModel.contactPersonNumber ==
                                                null ||
                                            addressModel.contactPersonNumber!.isEmpty)) {
                                      customSnackBar(
                                        "please_input_contact_person_name_and_phone_number"
                                            .tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (checkoutController.isCheckedCreateAccount &&
                                        checkoutController.passwordController.text.isEmpty) {
                                      customSnackBar(
                                        "please_input_new_account_password".tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (checkoutController.isCheckedCreateAccount &&
                                        checkoutController.confirmPasswordController.text.isEmpty) {
                                      customSnackBar(
                                        "please_input_confirm_password".tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (checkoutController.isCheckedCreateAccount &&
                                        checkoutController.confirmPasswordController.text !=
                                            checkoutController.passwordController.text) {
                                      customSnackBar(
                                        "confirm_password_does_not_matched".tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else {
                                      if (checkoutController
                                              .isCheckedCreateAccount &&
                                          !isLoggedIn &&
                                          createGuestAccount) {
                                        checkoutController
                                            .checkExistingUser(
                                              phone:
                                                  "${addressModel.contactPersonNumber}",
                                            )
                                            .then((value) {
                                              if (!value) {
                                                customSnackBar(
                                                  'phone_already_taken'.tr,
                                                  type: ToasterMessageType.info,
                                                );
                                              } else {
                                                checkoutController.updateState(
                                                  PageState.payment,
                                                );
                                                // if(GetPlatform.isWeb) {
                                                //   Get.toNamed(RouteHelper.getCheckoutRoute(
                                                //     'cart',Get.find<CheckOutController>().currentPageState.name,widget.pageState == 'payment' ? widget.addressId : addressModel.id.toString(),
                                                //     reload: false,
                                                //   ));
                                                // }
                                              }
                                            });
                                      } else {
                                        checkoutController.updateState(
                                          PageState.payment,
                                        );
                                        // if(GetPlatform.isWeb) {
                                        //   Get.toNamed(RouteHelper.getCheckoutRoute(
                                        //     'cart',Get.find<CheckOutController>().currentPageState.name,widget.pageState == 'payment' ? widget.addressId : addressModel.id.toString(),
                                        //     reload: false,
                                        //   ));
                                        // }
                                      }
                                    }
                                  } else if (checkoutController
                                              .currentPageState ==
                                          PageState.payment ||
                                      PageState.payment.name ==
                                          widget.pageState) {
                                    checkoutController.saveProDiscountAmount(
                                      (cartController.totalProDiscountAmount)
                                          .toString(),
                                    );

                                    if (cartController
                                            .walletPaymentStatus &&
                                        isPartialPayment &&
                                        checkoutController
                                                .selectedPaymentMethod ==
                                            PaymentMethodName.walletMoney) {
                                      customSnackBar(
                                        "select_another_payment_method_to_pay_remaining_bill"
                                            .tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (checkoutController
                                            .selectedPaymentMethod ==
                                        PaymentMethodName.none) {
                                      customSnackBar(
                                        "select_payment_method".tr,
                                        type: ToasterMessageType.info,
                                      );
                                    } else if (checkoutController
                                            .selectedPaymentMethod ==
                                        PaymentMethodName.cos) {
                                      checkoutController.placeBookingRequest(
                                        paymentMethod: "cash_after_service",
                                        schedule: schedule,
                                        isPartial:
                                            isPartialPayment &&
                                                cartController
                                                    .walletPaymentStatus
                                            ? 1
                                            : 0,
                                        address: addressModel!,
                                      );
                                    } else if (checkoutController
                                            .selectedPaymentMethod ==
                                        PaymentMethodName.walletMoney) {
                                      checkoutController.placeBookingRequest(
                                        paymentMethod: "wallet_payment",
                                        schedule: schedule,
                                        isPartial:
                                            isPartialPayment &&
                                                cartController
                                                    .walletPaymentStatus
                                            ? 1
                                            : 0,
                                        address: addressModel!,
                                      );
                                    } else if (checkoutController
                                            .selectedPaymentMethod ==
                                        PaymentMethodName.offline) {
                                      double bookingAmount = isPartialPayment
                                          ? (totalAmount -
                                                cartController.walletBalance)
                                          : totalAmount;
                                      if (checkoutController
                                              .selectedOfflineMethod !=
                                          null) {
                                        int selectedOfflinePaymentIndex =
                                            checkoutController
                                                .offlinePaymentModelList
                                                .indexOf(
                                                  checkoutController
                                                      .selectedOfflineMethod!,
                                                );
                                        checkoutController.placeBookingRequest(
                                          paymentMethod: "offline_payment",
                                          schedule: schedule,
                                          isPartial:
                                              isPartialPayment &&
                                                  cartController
                                                      .walletPaymentStatus
                                              ? 1
                                              : 0,
                                          address: addressModel!,
                                          offlinePaymentId: checkoutController
                                              .selectedOfflineMethod
                                              ?.id,
                                          selectedOfflinePaymentIndex:
                                              selectedOfflinePaymentIndex != -1
                                              ? selectedOfflinePaymentIndex
                                              : 0,
                                          bookingAmount: bookingAmount,
                                        );
                                      } else {
                                        customSnackBar(
                                          "provide_offline_payment_info".tr,
                                          type: ToasterMessageType.info,
                                        );
                                      }
                                    } else if (checkoutController
                                            .selectedPaymentMethod ==
                                        PaymentMethodName.digitalPayment) {
                                      if (checkoutController
                                                  .selectedDigitalPaymentMethod !=
                                              null &&
                                          checkoutController
                                                  .selectedDigitalPaymentMethod
                                                  ?.gateway !=
                                              "offline") {
                                        _makeDigitalPayment(
                                          addressModel,
                                          checkoutController
                                              .selectedDigitalPaymentMethod,
                                          isPartialPayment,
                                          checkoutController,
                                        );
                                      } else {
                                        customSnackBar(
                                          "select_any_payment_method".tr,
                                          type: ToasterMessageType.info,
                                        );
                                      }
                                    }
                                  }
                                } else {
                                  customSnackBar(
                                    'please_agree_with_terms_conditions'.tr,
                                    type: ToasterMessageType.info,
                                  );
                                }
                              },
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  Future<void> _makeDigitalPayment(
    AddressModel? address,
    DigitalPaymentMethod? paymentMethod,
    bool isPartialPayment,
    CheckOutController checkoutController,
  ) async {
    final scheduling = Get.find<ScheduleController>();
    final repeat = scheduling.selectedServiceType == ServiceType.repeat;
    final repeatDates = repeat
        ? CheckoutHelper.getRepeatBookingScheduleList(
            repeatBookingType: scheduling.selectedRepeatBookingType,
            dateRange: scheduling.selectedRepeatBookingType == RepeatBookingType.daily
                ? scheduling.pickedDailyRepeatBookingDateRange
                : scheduling.pickedWeeklyRepeatBookingDateRange,
            time: scheduling.selectedRepeatBookingType == RepeatBookingType.daily
                ? scheduling.pickedDailyRepeatTime
                : scheduling.pickedWeeklyRepeatTime,
            dateTimeList: scheduling.pickedCustomRepeatBookingDateTimeList,
            selectedDays: scheduling.getWeeklyPickedDays(),
          )
        : null;
    if (address == null ||
        (repeat && (repeatDates == null || repeatDates == '[]')) ||
        (!repeat && (scheduling.scheduleTime == null ||
            !await scheduling.validateRealAvailability(
              address,
              scheduling.scheduleTime!,
            )))) {
      customSnackBar('selected_slot_is_no_longer_available'.tr);
      return;
    }
    final partial =
        Get.find<CartController>().walletPaymentStatus && isPartialPayment
        ? 1
        : 0;
    if (!await checkoutController.reviewCheckoutPrice(
      address,
      scheduling.scheduleTime,
      paymentMethod: paymentMethod?.gateway ?? '',
      isPartial: partial,
    )) {
      return;
    }
    String url = '';
    SignUpBody? newUserInfo = CheckoutHelper.getNewUserInfo(
      address: address,
      password: checkoutController.passwordController.text,
      isCheckedCreateAccount: checkoutController.isCheckedCreateAccount,
    );

    String? schedule = Get.find<ScheduleController>().scheduleTime;

    String encodedAddress = base64Encode(
      utf8.encode(jsonEncode(address.toJson())),
    );
    String encodedNewUserInfo = base64Encode(
      utf8.encode(jsonEncode(newUserInfo?.toJson())),
    );
    String serviceLocation =
        Get.find<LocationController>().selectedServiceLocationType.name;

    String addressId = (address.id == "null" || address.id == null)
        ? ""
        : address.id ?? "";
    String zoneId = address.zoneId ?? '';
    String callbackUrl = GetPlatform.isWeb
        ? Uri.base.replace(query: '', fragment: '').toString()
        : AppConstants.baseUrl;
    int isPartial =
        Get.find<CartController>().walletPaymentStatus && isPartialPayment
        ? 1
        : 0;
    String platform = ResponsiveHelper.isWeb() ? "web" : "app";

    final sessionUrl = await PaymentSessionHelper.create({
      'payment_method': paymentMethod?.gateway,
      'zone_id': zoneId,
      'service_schedule': schedule,
      'service_address_id': addressId,
      'callback': callbackUrl,
      'service_address': encodedAddress,
      'new_user_info': encodedNewUserInfo,
      'is_partial': isPartial,
      'checkout_snapshot_id': checkoutController.checkoutSnapshotId,
      'service_type': scheduling.selectedServiceType.name,
      'booking_type': scheduling.selectedRepeatBookingType.name,
      'dates': repeatDates,
      'payment_platform': platform,
      'service_location': serviceLocation,
      'provider_id': scheduling.resolvedProviderId,
      'branch_selection':
          Get.find<CartController>().checkoutItems.firstOrNull?.provider?.id ==
              null
          ? 'auto'
          : 'manual',
    });
    if (sessionUrl == null) return;
    url = sessionUrl;

    if (GetPlatform.isWeb) {
      html.window.open(url, "_self");
    } else {
      Get.to(() => PaymentScreen(url: url, fromPage: "checkout"));
    }
  }
}
