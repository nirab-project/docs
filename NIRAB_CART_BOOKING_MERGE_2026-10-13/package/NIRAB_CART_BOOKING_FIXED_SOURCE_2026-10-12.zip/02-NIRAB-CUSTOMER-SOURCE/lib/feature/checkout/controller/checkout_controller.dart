import 'package:demandium/common/widgets/nirab/nirab_icon.dart';
import 'dart:convert';
import 'package:demandium/common/widgets/confirmation_widget.dart';
import 'package:demandium/feature/checkout/model/payment_response_model.dart';
import 'package:demandium/util/core_export.dart';
import 'package:get/get.dart';

enum PageState { orderDetails, payment, complete }

enum PaymentMethodName { digitalPayment, cos, walletMoney, offline, none }

class CheckOutController extends GetxController implements GetxService {
  final CheckoutRepo checkoutRepo;
  CheckOutController({required this.checkoutRepo});

  String? checkoutSnapshotId;
  double? approvedCheckoutTotal;
  double approvedWalletAmount = 0;
  bool _reviewingPrice = false;
  int _priceRevision = 0;
  bool _submittingBooking = false;

  void invalidatePrice() {
    _priceRevision++;
    checkoutSnapshotId = null;
    approvedCheckoutTotal = null;
    approvedWalletAmount = 0;
  }

  Future<bool> reviewCheckoutPrice(
    AddressModel address,
    String? schedule, {
    required String paymentMethod,
    int isPartial = 0,
  }) async {
    if (_reviewingPrice) return false;
    _reviewingPrice = true;
    final revision = _priceRevision;
    checkoutSnapshotId = null;
    approvedCheckoutTotal = null;
    approvedWalletAmount = 0;
    try {
      final scheduling = Get.find<ScheduleController>();
      final repeatType = scheduling.selectedRepeatBookingType;
      final dates = CheckoutHelper.getRepeatBookingScheduleList(
        repeatBookingType: repeatType,
        dateRange: repeatType == RepeatBookingType.daily
            ? scheduling.pickedDailyRepeatBookingDateRange
            : scheduling.pickedWeeklyRepeatBookingDateRange,
        time: repeatType == RepeatBookingType.daily
            ? scheduling.pickedDailyRepeatTime
            : scheduling.pickedWeeklyRepeatTime,
        dateTimeList: scheduling.pickedCustomRepeatBookingDateTimeList,
        selectedDays: scheduling.getWeeklyPickedDays(),
      );
      final response = await checkoutRepo
          .checkoutPrice({
            'checkout_cart_ids': Get.find<CartController>().checkoutCartIds,
            'guest_id': Get.find<SplashController>().getGuestId(),
            'zone_id': address.zoneId,
            'service_address_id': address.id == 'null' || address.id == ''
                ? null
                : address.id,
            'service_address': jsonEncode(address.toJson()),
            'service_schedule': schedule,
            'service_type': scheduling.selectedServiceType.name,
            'service_location':
                Get.find<LocationController>().selectedServiceLocationType.name,
            'booking_type': repeatType.name,
            'dates': dates,
            'provider_id': scheduling.resolvedProviderId,
            'branch_selection':
                Get.find<CartController>()
                        .checkoutItems
                        .firstOrNull
                        ?.provider
                        ?.id ==
                    null
                ? 'auto'
                : 'manual',
            'payment_method': paymentMethod,
            'is_partial': isPartial,
          })
          .timeout(const Duration(seconds: 30));
      if (response.statusCode != 200 ||
          response.body is! Map ||
          response.body['content'] is! Map) {
        final reason = response.body is Map
            ? '${response.body['error_code'] ?? response.body['message'] ?? ''}'
            : '';
        customSnackBar(
          reason == 'no_branch_for_all_services_split_required'
              ? 'split_cart_or_change_schedule'.tr
              : [
                  'checkout_price_changed',
                  'checkout_price_expired',
                  'checkout_cart_changed',
                ].contains(reason)
              ? 'checkout_price_changed_review_again'.tr
              : 'checkout_price_unavailable'.tr,
        );
        return false;
      }
      final data = Map<String, dynamic>.from(response.body['content']);
      final total = double.tryParse(data['total'].toString());
      final wallet = double.tryParse(data['wallet_amount'].toString()) ?? 0;
      if (total == null ||
          !total.isFinite ||
          data['checkout_snapshot_id'] == null) {
        return false;
      }
      final groups = (data['groups'] as List).whereType<Map>();
      final detail = groups
          .map((group) {
            final visits = (group['visits'] as List).whereType<Map>();
            final times = visits
                .map(
                  (visit) =>
                      '${visit['schedule']} · ${PriceConverter.convertPrice(double.tryParse(visit['totals']['total_booking_amount'].toString()) ?? 0)}',
                )
                .join('\n');
            return '${group['branch_name']} · ${visits.length} ${'checkout_visits'.tr}\n$times';
          })
          .join('\n');
      final accepted = await Get.dialog<bool>(
        ConfirmationDialog(
          iconWidget: const NirabIcon(Icons.receipt_long_outlined),
          title:
              '${'approved_checkout_total'.tr}: ${PriceConverter.convertPrice(total)}',
          description:
              '$detail\n${data['timezone']}\n${'wallet'.tr}: ${PriceConverter.convertPrice(wallet)}\n${'remaining_payment'.tr}: ${PriceConverter.convertPrice(total - wallet)}',
          yesButtonText: 'confirm_booking'.tr,
          noButtonText: 'cancel'.tr,
          onYesPressed: () => Get.back(result: true),
          onNoPressed: () => Get.back(result: false),
        ),
      );
      if (accepted != true || revision != _priceRevision) return false;
      checkoutSnapshotId = data['checkout_snapshot_id'].toString();
      approvedCheckoutTotal = total;
      approvedWalletAmount = wallet;
      update();
      return true;
    } catch (_) {
      customSnackBar('checkout_price_unavailable'.tr);
      return false;
    } finally {
      _reviewingPrice = false;
    }
  }

  PageState currentPageState = PageState.orderDetails;
  var selectedPaymentMethod = PaymentMethodName.none;
  bool showCoupon = false;
  bool cancelPayment = false;

  PostDetailsContent? postDetails;
  double totalAmount = 0.0;
  double referralDiscountAmount = 0.0;
  double totalVat = 0.0;

  String? proDiscountAmount;

  DigitalPaymentMethod? _selectedDigitalPaymentMethod;
  DigitalPaymentMethod? get selectedDigitalPaymentMethod =>
      _selectedDigitalPaymentMethod;

  OfflinePaymentModel? _selectedOfflineMethod;
  OfflinePaymentModel? get selectedOfflineMethod => _selectedOfflineMethod;

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  List<TextEditingController> _offlinePaymentInputField = [];
  List<TextEditingController> get offlinePaymentInputField =>
      _offlinePaymentInputField;

  List<Map<String, String>> _offlinePaymentInputFieldValues = [];
  List<Map<String, String>> get offlinePaymentInputFieldValues =>
      _offlinePaymentInputFieldValues;

  List<DigitalPaymentMethod> _digitalPaymentList = [];
  List<DigitalPaymentMethod> get digitalPaymentList => _digitalPaymentList;

  List<PaymentMethodButton> _othersPaymentList = [];
  List<PaymentMethodButton> get othersPaymentList => _othersPaymentList;

  List<OfflinePaymentModel> _offlinePaymentModelList = [];
  List<OfflinePaymentModel> get offlinePaymentModelList =>
      _offlinePaymentModelList;

  bool _acceptTerms = false;
  bool get acceptTerms => _acceptTerms;

  bool _isPlacedOrderSuccessfully = true;
  bool get isPlacedOrderSuccessfully => _isPlacedOrderSuccessfully;

  String _bookingReadableId = "";
  String get bookingReadableId => _bookingReadableId;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  bool _loading = false;
  bool get loading => _loading;

  bool _isCheckedCreateAccount = false;
  bool get isCheckedCreateAccount => _isCheckedCreateAccount;

  var passwordController = TextEditingController();
  var confirmPasswordController = TextEditingController();

  void updateState(PageState currentPage, {bool shouldUpdate = true}) {
    currentPageState = currentPage;
    if (shouldUpdate) {
      update();
    }
  }

  void changePaymentMethod({
    DigitalPaymentMethod? digitalMethod,
    OfflinePaymentModel? offlinePaymentModel,
    bool walletPayment = false,
    bool cashAfterService = false,
    bool shouldUpdate = true,
  }) {
    if (offlinePaymentModel != null) {
      _selectedOfflineMethod = offlinePaymentModel;
      selectedPaymentMethod = PaymentMethodName.offline;
    } else if (digitalMethod != null) {
      _selectedDigitalPaymentMethod = digitalMethod;
      _selectedOfflineMethod = null;
      selectedPaymentMethod = PaymentMethodName.digitalPayment;
    } else if (walletPayment) {
      _selectedDigitalPaymentMethod = null;
      _selectedOfflineMethod = null;
      selectedPaymentMethod = PaymentMethodName.walletMoney;
    } else if (cashAfterService) {
      _selectedDigitalPaymentMethod = null;
      _selectedOfflineMethod = null;
      selectedPaymentMethod = PaymentMethodName.cos;
    } else {
      _autoSelectPaymentMethod();
    }

    if (shouldUpdate) {
      update();
    }
  }

  void _autoSelectPaymentMethod() {
    if (_othersPaymentList.isNotEmpty &&
        _othersPaymentList.length == 1 &&
        _digitalPaymentList.isEmpty) {
      selectedPaymentMethod =
          _othersPaymentList[0].paymentMethodName == PaymentMethodName.cos
          ? PaymentMethodName.cos
          : PaymentMethodName.walletMoney;
    } else if (_othersPaymentList.isEmpty &&
        _digitalPaymentList.isNotEmpty &&
        _digitalPaymentList.length == 1) {
      if (_digitalPaymentList[0].gateway != "offline") {
        selectedPaymentMethod = PaymentMethodName.digitalPayment;
        _selectedDigitalPaymentMethod = _digitalPaymentList[0];
      } else {
        selectedPaymentMethod = PaymentMethodName.offline;
        _selectedDigitalPaymentMethod = _digitalPaymentList[0];
      }
    } else {
      selectedPaymentMethod = PaymentMethodName.none;
      _selectedDigitalPaymentMethod = null;
      _selectedOfflineMethod = null;
    }
  }

  void initializedOfflinePaymentTextField({
    bool shouldUpdate = false,
    List<BookingOfflinePayment>? existingData,
    String? existingOfflineId,
  }) {
    _offlinePaymentInputField = [];
    _offlinePaymentInputFieldValues = [];
    for (
      int i = 0;
      i < selectedOfflineMethod!.customerInformation!.length;
      i++
    ) {
      if (selectedOfflineMethod?.id == existingOfflineId &&
          existingData != null) {
        int? index = existingData.indexWhere(
          (element) =>
              element.key ==
              selectedOfflineMethod!.customerInformation?[i].fieldName,
        );
        Get.find<CheckOutController>().offlinePaymentInputField.add(
          TextEditingController(
            text: index != -1 ? existingData[index].value : "",
          ),
        );
      } else {
        Get.find<CheckOutController>().offlinePaymentInputField.add(
          TextEditingController(),
        );
      }
    }
    if (shouldUpdate) {
      update();
    }
  }

  Future<void> placeBookingRequest({
    required String paymentMethod,
    String? schedule,
    int isPartial = 0,
    required AddressModel address,
    String? offlinePaymentId,
    String? customerInformation,
    double? bookingAmount,
    int? selectedOfflinePaymentIndex,
  }) async {
    if (_submittingBooking) return;
    _submittingBooking = true;
    try {
      final retrying = checkoutRepo.hasPendingBookingConfirmation;
      if (retrying) {
        final resume = await Get.dialog<bool>(
          AlertDialog(
            title: Text('ux_pending_confirmation'.tr),
            content: Text(
              '${'ux_retry_same_booking'.tr}\n${checkoutRepo.pendingBookingSchedule ?? ''}\n${PriceConverter.convertPrice(checkoutRepo.pendingBookingTotal)}',
            ),
            actions: [
              TextButton(
                onPressed: () => Get.back(result: false),
                child: Text('cancel'.tr),
              ),
              TextButton(
                onPressed: () => Get.back(result: true),
                child: Text('retry'.tr),
              ),
            ],
          ),
        );
        if (resume != true) return;
      }
      paymentMethod = checkoutRepo.pendingBookingPaymentMethod ?? paymentMethod;
      String zoneId = address.zoneId ?? '';
      var scheduleController = Get.find<ScheduleController>();

      ServiceType serviceType = scheduleController.selectedServiceType;
      RepeatBookingType repeatBookingType =
          scheduleController.selectedRepeatBookingType;

      SignUpBody? newUserInfo = CheckoutHelper.getNewUserInfo(
        address: address,
        password: passwordController.text,
        isCheckedCreateAccount: isCheckedCreateAccount,
      );

      String? repeatBookingDates = CheckoutHelper.getRepeatBookingScheduleList(
        repeatBookingType: repeatBookingType,
        dateRange: repeatBookingType == RepeatBookingType.daily
            ? scheduleController.pickedDailyRepeatBookingDateRange
            : scheduleController.pickedWeeklyRepeatBookingDateRange,
        time: repeatBookingType == RepeatBookingType.daily
            ? scheduleController.pickedDailyRepeatTime
            : scheduleController.pickedWeeklyRepeatTime,
        dateTimeList: scheduleController.pickedCustomRepeatBookingDateTimeList,
        selectedDays: scheduleController.getWeeklyPickedDays(),
      );

      if (!retrying &&
          serviceType == ServiceType.regular &&
          (schedule == null ||
              scheduleController.resolvedProviderId == null ||
              !await scheduleController.validateRealAvailability(
                address,
                schedule,
              ))) {
        customSnackBar(
          'selected_slot_is_no_longer_available'.tr,
          type: ToasterMessageType.info,
        );
        return;
      }

      if (!retrying && serviceType == ServiceType.repeat) {
        final dates = (jsonDecode(repeatBookingDates ?? '[]') as List)
            .whereType<Map>();
        if (dates.isEmpty) {
          customSnackBar('no_available_slots'.tr);
          return;
        }
      }

      if (!retrying &&
          !await reviewCheckoutPrice(
            address,
            schedule,
            paymentMethod: paymentMethod,
            isPartial: isPartial,
          )) {
        return;
      }
      bookingAmount =
          ((retrying
                  ? checkoutRepo.pendingBookingTotal
                  : approvedCheckoutTotal) ??
              0) -
          (paymentMethod == 'offline_payment'
              ? (retrying
                    ? checkoutRepo.pendingBookingWallet
                    : approvedWalletAmount)
              : 0);
      _isLoading = true;
      update();

      if (retrying || Get.find<CartController>().checkoutItems.isNotEmpty) {
        Response response = await checkoutRepo.placeBookingRequest(
          paymentMethod: paymentMethod,
          zoneId: zoneId,
          schedule: schedule,
          serviceAddressID: address.id == "null" ? "" : address.id,
          serviceAddress: address,
          isPartial: isPartial,
          serviceType: serviceType.name,
          bookingType: repeatBookingType.name,
          dates: repeatBookingDates,
          newUserInfo: newUserInfo,
          serviceLocation:
              Get.find<LocationController>().selectedServiceLocationType.name,
          providerId: scheduleController.resolvedProviderId,
        );
        if (response.statusCode == 200 &&
            response.body["response_code"] == "booking_place_success_200") {
          Get.find<CheckOutController>().getProDiscountAmount();
          _isPlacedOrderSuccessfully = true;
          _bookingReadableId = response.body['content']['readable_id']
              .toString();
          String? token = response.body['content']['token'];
          Get.find<CartController>().getCartListFromServer();

          if (paymentMethod != "offline_payment") {
            updateState(PageState.complete);
            if (ResponsiveHelper.isWeb()) {
              String token = base64Encode(
                utf8.encode("&&attribute_id=$_bookingReadableId"),
              );
              Get.toNamed(
                RouteHelper.getCheckoutRoute(
                  'cart',
                  Get.find<CheckOutController>().currentPageState.name,
                  "null",
                  token: token,
                ),
              );
            }

            customSnackBar(
              '${response.body['message']}'.tr,
              type: ToasterMessageType.success,
              margin: 55,
            );
          } else {
            String? bookingId = response.body['content']['booking_id'][0];
            customSnackBar(
              'now_pay_you_bill_using_the_payment_method'.tr,
              toasterTitle: 'your_booking_has_been_placed_successfully'.tr,
              type: ToasterMessageType.success,
              duration: 4,
            );
            Get.offAllNamed(
              RouteHelper.getOfflinePaymentRoute(
                totalAmount: bookingAmount,
                index: selectedOfflinePaymentIndex ?? 0,
                bookingId: bookingId,
                fromPage: "checkout",
                newUserInfo: newUserInfo,
                readableId: _bookingReadableId,
              ),
            );
          }

          if (token != null) {
            _saveTokenAndHandelPhoneVerification(
              token: token,
              userInfo: newUserInfo,
              paymentMethod: paymentMethod,
            );
          }
        } else {
          ApiChecker.checkApi(response);
        }
      } else {
        Get.offNamed(RouteHelper.getOrderSuccessRoute('fail'));
      }
    } catch (_) {
      customSnackBar('ux_request_retry'.tr);
    } finally {
      _submittingBooking = false;
      _isLoading = false;
      update();
    }
  }

  void _saveTokenAndHandelPhoneVerification({
    String? token,
    SignUpBody? userInfo,
    String? paymentMethod,
  }) {
    bool isActivePhoneVerification =
        Get.find<SplashController>().configModel.content?.phoneVerification == 1
        ? true
        : false;

    if (isActivePhoneVerification) {
      if (paymentMethod != "offline_payment") {
        Future.delayed(const Duration(seconds: 1), () {
          if (ResponsiveHelper.isDesktop(Get.context!)) {
            Get.dialog(
              Center(
                child: _guestCreateAccountPhoneVerificationTitle(
                  userInfo: userInfo,
                ),
              ),
            );
          } else {
            showModalBottomSheet(
              backgroundColor: Colors.transparent,
              context: Get.context!,
              builder: (_) {
                return _guestCreateAccountPhoneVerificationTitle(
                  userInfo: userInfo,
                );
              },
            );
          }
        });
      }
    } else {
      if (token != null) {
        Get.find<AuthController>().saveUserToken(token: token);
        Get.find<UserController>().getUserInfo();
      }
    }
  }

  Widget _guestCreateAccountPhoneVerificationTitle({SignUpBody? userInfo}) {
    return ConfirmationWidget(
      icon: Images.otp,
      iconSize: 100,
      title: "need_to_verify_your_phone",
      subtitleWidget: Text.rich(
        TextSpan(
          style: DefaultTextStyle.of(Get.context!).style,
          children: [
            TextSpan(
              text: 'account_created_successfully_verify_your_phone'.tr,
              style: robotoRegular.copyWith(
                color: Theme.of(
                  Get.context!,
                ).textTheme.bodySmall?.color?.withValues(alpha: 0.5),
                height: 1.5,
              ),
            ),
            TextSpan(
              text: StringParser.obfuscateMiddle("${userInfo?.phone}"),
              style: robotoMedium.copyWith(
                color: Theme.of(Get.context!).textTheme.bodyLarge!.color,
                height: 1.5,
              ),
            ),

            TextSpan(
              text: 'you_can_skip_now_but_later'.tr,
              style: robotoRegular.copyWith(
                color: Theme.of(
                  Get.context!,
                ).textTheme.bodySmall?.color?.withValues(alpha: 0.5),
                height: 1.5,
              ),
            ),
          ],
        ),
        textAlign: TextAlign.center,
      ),
      yesButtonColor: Theme.of(Get.context!).colorScheme.primary,
      yesButtonText: 'verify_now'.tr,
      noButtonText: "not_now".tr,
      onYesPressed: () async {
        var config = Get.find<SplashController>().configModel.content;
        String identity = userInfo?.phone ?? "";
        String identityType = "phone";
        SendOtpType type = config?.firebaseOtpVerification == 1
            ? SendOtpType.firebase
            : SendOtpType.verification;

        await Get.find<AuthController>()
            .sendVerificationCode(
              identity: identity,
              identityType: identityType,
              type: type,
            )
            .then((status) {
              if (status != null) {
                if (status.isSuccess!) {
                  Get.toNamed(
                    RouteHelper.getVerificationRoute(
                      identity: identity,
                      identityType: identityType,
                      fromPage:
                          config?.phoneVerification == 1 &&
                              config?.firebaseOtpVerification == 1
                          ? "firebase-otp"
                          : "verification",
                      firebaseSession: type == SendOtpType.firebase
                          ? status.message
                          : null,
                    ),
                  );
                } else {
                  customSnackBar(status.message.toString().capitalizeFirst);
                }
              }
            });
      },
    );
  }

  double? quotationPayableAmount;
  double? quotationOfferedAmount;
  double quotationInspectionDeduction = 0;
  bool quotationCanCheckout = false;
  String? quotationLoadError;
  int _quotationRevision = 0;

  Future<void> getPostDetails(String postID, String bidId) async {
    final revision = ++_quotationRevision;
    totalAmount = 0;
    quotationPayableAmount = null;
    quotationOfferedAmount = null;
    quotationInspectionDeduction = 0;
    quotationCanCheckout = false;
    quotationLoadError = null;
    postDetails = null;
    update();
    try {
      final response = await checkoutRepo.getPostDetails(postID, bidId);
      if (revision != _quotationRevision) return;
      if (response.statusCode != 200 ||
          response.body is! Map ||
          response.body['content'] is! Map)
        throw StateError('quotation');
      final content = response.body['content'];
      quotationPayableAmount = double.tryParse(
        '${content['quotation_payable_amount'] ?? ''}',
      );
      quotationOfferedAmount = double.tryParse(
        '${content['quotation_offered_amount'] ?? ''}',
      );
      quotationInspectionDeduction =
          double.tryParse(
            '${content['quotation_inspection_deduction'] ?? ''}',
          ) ??
          0;
      quotationCanCheckout =
          content['quotation_can_checkout'] == true &&
          quotationPayableAmount != null;
      postDetails = PostDetailsContent.fromJson(content['post_details']);
      calculateTotalAmount();
      if (postDetails?.serviceAddress != null) {
        Get.find<LocationController>().updateSelectedAddress(
          postDetails?.serviceAddress,
          shouldUpdate: false,
        );
      }
      if (!quotationCanCheckout) quotationLoadError = 'ux_quote_unavailable'.tr;
    } catch (_) {
      if (revision == _quotationRevision)
        quotationLoadError = 'ux_quote_load_failed'.tr;
    } finally {
      if (revision == _quotationRevision) update();
    }
  }

  Future<bool> checkExistingUser({required String phone}) async {
    _isLoading = true;
    update();
    Response? response = await checkoutRepo.checkExistingUser(phone: phone);

    if (response!.statusCode == 400 &&
        response.body['response_code'] == "user_exist_400") {
      _isLoading = false;
      update();
      return false;
    } else {
      _isLoading = false;
      update();
      return true;
    }
  }

  Future<void> submitOfflinePaymentData({
    required String bookingId,
    required String offlinePaymentId,
    required offlinePaymentInfo,
    required int isPartialPayment,
    required String fromPage,
    SignUpBody? newUserInfo,
    String? readableId,
  }) async {
    _isLoading = true;
    update();
    Response? response = await checkoutRepo.submitOfflinePaymentData(
      bookingId: bookingId,
      offlinePaymentId: offlinePaymentId,
      offlinePaymentInfo: offlinePaymentInfo,
      isPartialPayment: isPartialPayment,
    );

    if (response!.statusCode == 200) {
      customSnackBar(
        'now_wait_for_your_payment_to_be_verified'.tr,
        toasterTitle: "your_payment_confirm_successfully".tr,
        type: ToasterMessageType.success,
      );

      if (fromPage == "checkout") {
        String? token;
        if (readableId != null) {
          token = base64Encode(utf8.encode("&&attribute_id=$readableId"));
        }
        Get.toNamed(
          RouteHelper.getCheckoutRoute(
            'cart',
            "complete",
            "null",
            token: token,
          ),
        );
      } else if (fromPage == "custom-post") {
        Get.offNamed(RouteHelper.getOrderSuccessRoute('success'));
      } else {
        await Get.find<BookingDetailsController>().getBookingDetails(
          bookingId: bookingId,
        );
        if (Navigator.canPop(Get.context!)) {
          Get.back();
        } else {
          Get.offAllNamed(RouteHelper.getMainRoute('home'));
        }
      }

      if (fromPage == "checkout" &&
          Get.find<SplashController>().configModel.content?.phoneVerification ==
              1 &&
          !Get.find<AuthController>().isLoggedIn()) {
        Future.delayed(const Duration(seconds: 1), () {
          _saveTokenAndHandelPhoneVerification(userInfo: newUserInfo);
        });
      }
    } else {
      ApiChecker.checkApi(response);
    }

    _isLoading = false;
    update();
  }

  Future<void> switchPaymentMethod({
    required String bookingId,
    required String paymentMethod,
    int isPartial = 0,
    String? offlinePaymentId,
    String? offlinePaymentInfo,
  }) async {
    _isLoading = true;
    update();
    Response? response = await checkoutRepo.switchPaymentMethod(
      bookingId: bookingId,
      paymentMethod: paymentMethod,
      offlinePaymentId: offlinePaymentId,
      offlinePaymentInfo: offlinePaymentInfo,
      isPartial: isPartial,
    );

    if (response!.statusCode == 200) {
      await Get.find<BookingDetailsController>().getBookingDetails(
        bookingId: bookingId,
      );
      Get.back();
      customSnackBar(
        "your_payment_confirm_successfully".tr,
        type: ToasterMessageType.success,
        showDefaultSnackBar: false,
      );
    } else {
      ApiChecker.checkApi(response, showDefaultToaster: false);
    }

    _isLoading = false;
    update();
  }

  void calculateTotalAmount() {
    totalAmount = quotationPayableAmount ?? 0;
    totalVat = 0;
    referralDiscountAmount = 0;
  }

  Future<void> getOfflinePaymentMethod(
    bool isReload, {
    bool shouldUpdate = true,
    int? selectedIndex,
    AutoScrollController? scrollController,
  }) async {
    if (_offlinePaymentModelList.isEmpty || isReload) {
      _offlinePaymentModelList = [];
    }

    if (_offlinePaymentModelList.isEmpty) {
      _loading = true;
      Response response = await checkoutRepo.getOfflinePaymentMethod();
      if (response.statusCode == 200) {
        _offlinePaymentModelList = [];
        List<dynamic> list = response.body['content']['data'];
        for (var element in list) {
          _offlinePaymentModelList.add(OfflinePaymentModel.fromJson(element));
        }

        if (_offlinePaymentModelList.isNotEmpty) {
          if (selectedIndex == null ||
              _offlinePaymentModelList.length < selectedIndex) {
            _selectedOfflineMethod = _offlinePaymentModelList.first;
          } else {
            _selectedOfflineMethod = _offlinePaymentModelList[selectedIndex];

            if (selectedIndex != -1) {
              await scrollController!.scrollToIndex(
                selectedIndex,
                preferPosition: AutoScrollPosition.middle,
              );
              await scrollController.highlight(selectedIndex);
            }
          }
        }
      }
      _loading = false;
      update();
    }
  }

  Future<PaymentResponseModel?> getDigitalPaymentResponse({
    String? transactionId,
  }) async {
    Response response = await checkoutRepo.getDigitalPaymentResponse(
      transactionId: transactionId,
    );

    PaymentResponseModel? paymentResponseModel;
    if (response.statusCode == 200) {
      paymentResponseModel = PaymentResponseModel.fromJson(response.body);
    }

    return paymentResponseModel;
  }

  void getPaymentMethodList({
    bool shouldUpdate = false,
    bool isPartialPayment = false,
    bool avoidPartialPayment = false,
  }) {
    final ConfigModel configModel = Get.find<SplashController>().configModel;
    _digitalPaymentList = [];
    _othersPaymentList = [];
    _isLoading = false;

    if (isPartialPayment &&
        configModel.content?.partialPaymentCombinator != "all" &&
        configModel.content?.partialPayment == 1) {
      if (configModel.content?.partialPaymentCombinator == "digital_payment") {
        _othersPaymentList = [
          if (configModel.content?.walletStatus == 1 &&
              Get.find<AuthController>().isLoggedIn() &&
              Get.find<CartController>().walletBalance > 0 &&
              !avoidPartialPayment)
            PaymentMethodButton(
              title: "pay_via_wallet".tr,
              paymentMethodName: PaymentMethodName.walletMoney,
              assetName: Images.walletMenu,
            ),
        ];
        if (configModel.content?.digitalPayment == 1) {
          digitalPaymentList.addAll(
            configModel.content?.paymentMethodList ?? [],
          );
        }
      } else if (configModel.content?.partialPaymentCombinator ==
          "cash_after_service") {
        _digitalPaymentList = [];
        _othersPaymentList = [
          if (configModel.content?.walletStatus == 1 &&
              Get.find<AuthController>().isLoggedIn() &&
              Get.find<CartController>().walletBalance > 0 &&
              !avoidPartialPayment)
            PaymentMethodButton(
              title: "pay_via_wallet".tr,
              paymentMethodName: PaymentMethodName.walletMoney,
              assetName: Images.walletMenu,
            ),
          if (configModel.content?.cashAfterService == 1)
            PaymentMethodButton(
              title: "pay_after_service".tr,
              paymentMethodName: PaymentMethodName.cos,
              assetName: Images.cod,
            ),
        ];
      } else if (configModel.content?.partialPaymentCombinator ==
          "offline_payment") {
        _othersPaymentList = [
          if (configModel.content?.walletStatus == 1 &&
              Get.find<AuthController>().isLoggedIn() &&
              Get.find<CartController>().walletBalance > 0 &&
              !avoidPartialPayment)
            PaymentMethodButton(
              title: "pay_via_wallet".tr,
              paymentMethodName: PaymentMethodName.walletMoney,
              assetName: Images.walletMenu,
            ),
        ];
        if (configModel.content?.offlinePayment == 1) {
          digitalPaymentList.add(
            DigitalPaymentMethod(gateway: "offline", gatewayImage: ""),
          );
        }
      }
    } else {
      _othersPaymentList = [
        if (configModel.content?.walletStatus == 1 &&
            Get.find<AuthController>().isLoggedIn() &&
            Get.find<CartController>().walletBalance > 0 &&
            !avoidPartialPayment)
          PaymentMethodButton(
            title: "pay_via_wallet".tr,
            paymentMethodName: PaymentMethodName.walletMoney,
            assetName: Images.walletMenu,
          ),

        if (configModel.content?.cashAfterService == 1)
          PaymentMethodButton(
            title: "pay_after_service".tr,
            paymentMethodName: PaymentMethodName.cos,
            assetName: Images.cod,
          ),
      ];

      if (configModel.content?.digitalPayment == 1) {
        digitalPaymentList.addAll(configModel.content?.paymentMethodList ?? []);
      }
      if (configModel.content?.offlinePayment == 1) {
        digitalPaymentList.add(
          DigitalPaymentMethod(gateway: "offline", gatewayImage: ""),
        );
      }
    }
    if (shouldUpdate) {
      update();
    }
  }

  void parseToken(String token) async {
    try {
      _bookingReadableId = StringParser.parseString(
        utf8.decode(base64Url.decode(token)),
        "attribute_id",
      );
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    }

    String? transactionId;
    try {
      transactionId = StringParser.parseString(
        utf8.decode(base64Url.decode(token)),
        "transaction_reference",
      );

      if (transactionId.isNotEmpty) {
        PaymentResponseModel? paymentResponse = await getDigitalPaymentResponse(
          transactionId: transactionId,
        );

        if (paymentResponse != null) {
          String? loginToken = paymentResponse.content?.loginToken;
          String? phone = paymentResponse.content?.newUserPhone;

          SignUpBody? newUserInfo = SignUpBody(phone: phone);
          if (phone != null) {
            _saveTokenAndHandelPhoneVerification(
              token: loginToken,
              userInfo: newUserInfo,
              paymentMethod: "",
            );
          }
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    }
  }

  void updateBookingPlaceStatus({
    bool status = true,
    bool shouldUpdate = false,
  }) {
    _isPlacedOrderSuccessfully = status;
    if (shouldUpdate) {
      update();
    }
  }

  void toggleTerms({bool? value, bool shouldUpdate = true}) {
    if (value != null) {
      _acceptTerms = value;
    } else {
      _acceptTerms = !_acceptTerms;
    }
    if (shouldUpdate) {
      update();
    }
  }

  void toggleIsCheckedCreateAccount({bool? value, bool shouldUpdate = true}) {
    if (value != null) {
      _isCheckedCreateAccount = value;
    } else {
      _isCheckedCreateAccount = !_isCheckedCreateAccount;
    }
    if (shouldUpdate) {
      update();
    }
  }

  void resetCreateAccountWithExistingInfo() {
    _isCheckedCreateAccount = false;
    passwordController.clear();
    confirmPasswordController.clear();
  }

  void getDigitalPaymentList() {
    final ConfigModel configModel = Get.find<SplashController>().configModel;
    _digitalPaymentList = [];

    if (configModel.content?.digitalPayment == 1) {
      digitalPaymentList.addAll(configModel.content?.paymentMethodList ?? []);
    }
  }

  void saveProDiscountAmount(String amount) {
    checkoutRepo.saveProDiscountAmount(amount);
  }

  void getProDiscountAmount() {
    proDiscountAmount = checkoutRepo.getProDiscountAmount();
  }

  void setPreviousRoute(String route) {
    checkoutRepo.setPreviousRoute(route);
  }

  String? getPreviousRoute() {
    return checkoutRepo.getPreviousRoute();
  }
}
