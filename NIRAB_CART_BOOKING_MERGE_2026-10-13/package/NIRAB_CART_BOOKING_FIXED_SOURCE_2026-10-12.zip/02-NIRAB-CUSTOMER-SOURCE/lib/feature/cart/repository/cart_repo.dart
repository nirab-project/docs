import 'package:demandium/common/models/api_response_model.dart';
import 'package:demandium/common/repo/data_sync_repo.dart';
import 'package:demandium/util/core_export.dart';
import 'package:get/get.dart';

class CartRepo extends DataSyncRepo {
  Future<Response> previewServicePrice(Map<String, dynamic> input) =>
      apiClient.postData(AppConstants.priceBreakdown, input);
  CartRepo({
    required super.apiClient,
    required SharedPreferences super.sharedPreferences,
  });

  Future<bool> _ensureGuestIdentity() async {
    if (Get.find<AuthController>().isLoggedIn()) return true;
    final token = sharedPreferences?.getString('nirab_guest_payment_token');
    final guest = sharedPreferences?.getString(AppConstants.guestId);
    if (token?.isNotEmpty == true && guest?.isNotEmpty == true) return true;
    return Get.find<SplashRepo>().ensurePaymentGuestSession();
  }

  Future<Response> addToCartListToServer(CartModelBody cartModel) async {
    if (!await _ensureGuestIdentity()) {
      return Response(statusCode: 401, statusText: 'guest_session_required');
    }
    if (!Get.find<AuthController>().isLoggedIn()) {
      cartModel.guestId = Get.find<SplashRepo>().getGuestId();
    }
    return await apiClient.postData(AppConstants.addToCart, cartModel.toJson());
  }

  Future<ApiResponseModel<T>> getCartListFromServer<T>({
    required DataSourceEnum source,
  }) async {
    if (source == DataSourceEnum.local) {
      return ApiResponseModel.withError('private_cart_cache_disabled');
    }
    if (!await _ensureGuestIdentity()) {
      return ApiResponseModel.withError('guest_session_required');
    }
    final response = await apiClient.getData(
      "${AppConstants.getCartList}&&guest_id=${Get.find<SplashController>().getGuestId()}",
    );
    // Avoid DataSyncRepo.fetchData: it caches private user data by URL alone.
    return ApiResponseModel.withSuccess(response as T);
  }

  Future<Response> removeCartFromServer(String cartID) async {
    return await apiClient.deleteData(
      "${AppConstants.removeCartItem}$cartID?guest_id=${Get.find<SplashController>().getGuestId()}",
    );
  }

  Future<Response> removeAllCartFromServer() async {
    return await apiClient.deleteData(
      "${AppConstants.removeAllCartItem}?guest_id=${Get.find<SplashController>().getGuestId()}",
    );
  }

  Future<Response> updateCartQuantity(String cartID, int quantity) async {
    return await apiClient.putData(
      "${AppConstants.updateCartQuantity}$cartID?guest_id=${Get.find<SplashController>().getGuestId()}",
      {'quantity': quantity},
    );
  }

  Future<Response> updateProvider(String providerId) async {
    return await apiClient.putData(AppConstants.updateCartProvider, {
      'provider_id': providerId,
      'checkout_cart_ids': Get.find<CartController>().checkoutCartIds,
      "guest_id": Get.find<SplashController>().getGuestId(),
    });
  }

  Future<Response> getProvidersForServices(List<String> serviceIds) async {
    final address = CheckoutHelper.selectedAddressModel(
      selectedAddress: Get.find<LocationController>().selectedAddress,
      pickedAddress: Get.find<LocationController>().getUserAddress(),
      selectedLocationType:
          Get.find<LocationController>().selectedServiceLocationType,
    );
    final values = <String, dynamic>{
      'service_ids[]': serviceIds,
      'latitude': address?.latitude ?? '',
      'longitude': address?.longitude ?? '',
    };
    return apiClient.getData(
      '${AppConstants.getProvidersForServices}?${Uri(queryParameters: values).query}',
    );
  }

  Future<Response> addRebookToServer(String bookingId) async {
    return await apiClient.postData(AppConstants.rebookApi, {
      'booking_id': bookingId,
      'guest_id': Get.find<SplashController>().getGuestId(),
    });
  }
}
