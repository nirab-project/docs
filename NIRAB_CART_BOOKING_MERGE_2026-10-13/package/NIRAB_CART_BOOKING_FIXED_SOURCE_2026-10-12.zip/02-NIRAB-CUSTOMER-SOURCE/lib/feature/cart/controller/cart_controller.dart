import 'dart:convert';
import 'package:demandium/common/widgets/nirab/nirab_icon.dart';
import 'package:demandium/api/local/cache_response.dart';
import 'package:demandium/helper/data_sync_helper.dart';
import 'package:get/get.dart';
import 'package:demandium/util/core_export.dart';

class CartController extends GetxController implements GetxService {
  final CartRepo cartRepo;
  CartController({required this.cartRepo});

  List<CartModel> _cartList = [];
  List<CartModel> _initialCartList = [];
  bool _isLoading = false;
  bool _isCartLoading = false;
  double _amount = 0.0;
  final bool _isOthersInfoValid = false;
  bool _isButton = false;

  List<CartModel> get cartList => _cartList;
  Set<String>? _checkoutCartIds;
  List<CartModel> get checkoutItems => _checkoutCartIds == null
      ? _cartList
      : _cartList.where((item) => _checkoutCartIds!.contains(item.id)).toList();
  List<String> get checkoutCartIds =>
      checkoutItems.map((item) => item.id).toList();
  void selectCheckoutItems(Set<String> ids) {
    _checkoutCartIds = ids;
    _selectedProvider = checkoutItems.firstOrNull?.provider;
    _invalidateBookingContext();
    updateBookingAmountWithoutCoupon();
    update();
  }

  void resetCheckoutSelection() {
    _checkoutCartIds = null;
  }

  List<CartModel> get initialCartList => _initialCartList;
  double get amount => _amount;
  bool get isLoading => _isLoading;
  bool get isCartLoading => _isCartLoading;
  bool get isOthersInfoValid => _isOthersInfoValid;

  bool get isButton => _isButton;

  List<ProviderData>? _providerList;
  List<ProviderData>? get providerList => _providerList;

  double _totalPrice = 0;
  double get totalPrice => _checkoutCartIds == null
      ? _totalPrice
      : checkoutItems.fold(0, (sum, item) => sum + item.totalCost);
  set updateTotalPrice(double price) => _totalPrice = price;

  double _walletBalance = 0.0;
  double get walletBalance => _walletBalance;

  double _referralAmount = 0.0;
  double get referralAmount => _referralAmount;

  double _bookingAmountWithoutCoupon = 0.0;
  double _couponAmount = 0.0;

  bool _walletPaymentStatus = false;
  bool get walletPaymentStatus => _walletPaymentStatus;

  ProviderData? _selectedProvider;
  ProviderData? get selectedProvider => _selectedProvider;

  double? proDiscountAmount;
  double totalProDiscountAmount = 0;

  String? proBenefitType;
  int selectedProviderIndex = -1;

  String _contextSignature() => checkoutItems
      .map(
        (item) =>
            '${item.serviceId}|${item.variantKey}|${item.quantity}|${item.provider?.id}|${jsonEncode(item.fieldAnswers)}',
      )
      .join(';');

  void _invalidateBookingContext() {
    if (Get.isRegistered<ScheduleController>()) {
      Get.find<ScheduleController>().invalidateBookingContext(notify: false);
    }
  }

  Future<void> getCartListFromServer({bool shouldUpdate = true}) async {
    proDiscountAmount = null;
    totalProDiscountAmount = 0;
    proBenefitType = null;

    await DataSyncHelper.fetchAndSyncData(
      fetchFromLocal: () => cartRepo.getCartListFromServer<CacheResponseData>(
        source: DataSourceEnum.local,
      ),
      fetchFromClient: () =>
          cartRepo.getCartListFromServer(source: DataSourceEnum.client),
      onResponse: (data, source) {
        final oldContext = _contextSignature();
        _cartList = [];
        data['content']['cart']['data'].forEach((cart) {
          _cartList.add(CartModel.fromJson(cart));
        });

        if (oldContext != _contextSignature()) _invalidateBookingContext();
        if (data['content']['wallet_balance'] != null) {
          _walletBalance = double.tryParse(
            data['content']['wallet_balance'].toString(),
          )!;
        }
        if (data['content']['total_cost'] != null) {
          _totalPrice = double.tryParse(
            data['content']['total_cost'].toString(),
          )!;
        }
        if (data['content']['referral_amount'] != null) {
          _referralAmount = double.tryParse(
            data['content']['referral_amount'].toString(),
          )!;
        }
        proDiscountAmount = double.tryParse(
          '${data['content']['pro_discount_amount']}',
        );
        proBenefitType = data['content']['pro_benefit_type'];

        _checkoutCartIds?.retainAll(_cartList.map((item) => item.id));
        if (_checkoutCartIds?.isEmpty ?? false) _checkoutCartIds = null;
        _selectedProvider = checkoutItems.firstOrNull?.provider;

        update();
      },
    );
  }

  Future<void> removeCartFromServer(CartModel cart) async {
    _invalidateBookingContext();
    _isLoading = true;
    Response response = await cartRepo.removeCartFromServer(cart.id);
    if (response.statusCode == 200 || response.statusCode == 204) {
      _cartList.remove(cart);
    }

    await getCartListFromServer(shouldUpdate: false);
    _isLoading = false;
    update();
  }

  Future<void> removeAllCartItem() async {
    _invalidateBookingContext();
    _isLoading = true;
    update();
    try {
      final response = await cartRepo.removeAllCartFromServer();
      if (response.statusCode == 200 || response.statusCode == 204) {
        await getCartListFromServer(shouldUpdate: false);
      } else {
        ApiChecker.checkApi(response);
      }
    } finally {
      _isLoading = false;
      update();
    }
  }

  Future<void> updateCartQuantityToApi(String cartID, int quantity) async {
    _invalidateBookingContext();
    _isCartLoading = true;
    update();

    Response response = await cartRepo.updateCartQuantity(cartID, quantity);
    if (response.statusCode == 200) {
      _cartList = [];
      response.body['content']['cart']['data'].forEach((cart) {
        _cartList.add(CartModel.fromJson(cart));
      });

      if (response.body['content']['wallet_balance'] != null) {
        _walletBalance = double.tryParse(
          response.body['content']['wallet_balance'].toString(),
        )!;
      }

      if (response.body['content']['total_cost'] != null) {
        _totalPrice = double.tryParse(
          response.body['content']['total_cost'].toString(),
        )!;
      }

      if (response.body['content']['referral_amount'] != null) {
        _referralAmount = double.tryParse(
          response.body['content']['referral_amount'].toString(),
        )!;
      }

      _checkoutCartIds?.retainAll(_cartList.map((item) => item.id));
      if (_checkoutCartIds?.isEmpty ?? false) _checkoutCartIds = null;
      _selectedProvider = checkoutItems.firstOrNull?.provider;
    }

    _isCartLoading = false;
    update();
  }

  Future<void> updateProvider(ProviderData? providerData) async {
    _invalidateBookingContext();

    _isCartLoading = true;
    update();
    final previousProvider = _selectedProvider;
    try {
      final response = await cartRepo.updateProvider(providerData?.id ?? "");
      if (response.statusCode == 200) {
        _selectedProvider = providerData;
        await getCartListFromServer();
        Get.find<ScheduleController>().buildSchedule(
          scheduleType: ScheduleType.asap,
        );
      } else {
        _selectedProvider = previousProvider;
        ApiChecker.checkApi(response);
      }
    } catch (_) {
      _selectedProvider = previousProvider;
      customSnackBar('something_went_wrong'.tr);
    } finally {
      _isCartLoading = false;
      update();
    }
  }

  void removeFromCartVariation(CartModel? cartModel) {
    if (cartModel == null) {
      _initialCartList = [];
    } else {
      _initialCartList.remove(cartModel);
      update();
    }
  }

  void removeFromCartList(int cartIndex) {
    _cartList[cartIndex].quantity = _cartList[cartIndex].quantity - 1;
    update();
  }

  void updateQuantity(int index, bool isIncrement) {
    if (isIncrement) {
      _initialCartList[index].quantity += 1;
      _totalPrice = _totalPrice + _initialCartList[index].totalCost;
    } else {
      if (_initialCartList[index].quantity > -1) {
        _initialCartList[index].quantity -= 1;
        _totalPrice = _totalPrice - _initialCartList[index].totalCost;
      }
    }
    _isButton = _isQuantity();
    update();
  }

  bool _isQuantity() {
    int count = 0;
    for (var cart in _initialCartList) {
      count += cart.quantity;
    }
    return count > 0;
  }

  void addDataToCart() {
    _replaceCartList();
    update();
    Get.back();
  }

  Future<void> addMultipleCartToServer({
    bool fromServiceCenterDialog = true,
    required String providerId,
  }) async {
    _invalidateBookingContext();
    _isLoading = true;
    update();
    bool success = true;
    try {
      for (final item in _initialCartList.where((item) => item.quantity > 0)) {
        if (!await addToCartApi(item, providerId: providerId)) {
          success = false;
          break;
        }
      }
      await getCartListFromServer();
      if (success && fromServiceCenterDialog) {
        Get.back();
        customSnackBar(
          'successfully_added_to_cart'.tr,
          type: ToasterMessageType.success,
        );
      }
    } finally {
      _isLoading = false;
      update();
    }
  }

  Future<bool> addToCartApi(
    CartModel cartModel, {
    required String providerId,
  }) async {
    _invalidateBookingContext();
    final response = await cartRepo.addToCartListToServer(
      CartModelBody(
        serviceId: cartModel.serviceId,
        variantKey: cartModel.variantKey,
        quantity: cartModel.quantity.toString(),
        fieldAnswers: cartModel.fieldAnswers,
        providerId: providerId.isEmpty ? null : providerId,
        guestId: Get.find<SplashController>().getGuestId(),
      ),
    );
    if (response.statusCode != 200) {
      ApiChecker.checkApi(response);
      return false;
    }
    return true;
  }

  void removeAllAndAddToCart(CartModel cartModel) {
    _invalidateBookingContext();
    _cartList = [];
    _cartList.add(cartModel);
    _amount = cartModel.discountedPrice.toDouble() * cartModel.quantity;
    update();
  }

  int isAvailableInCart(CartModel cartModel, Service service) {
    int index = -1;
    for (var cart in _cartList) {
      if (cart.service != null) {
        if (cart.service!.id!.contains(service.id!)) {
          service.variationsAppFormat?.zoneWiseVariations?.forEach((variation) {
            if (variation.variantKey == cart.variantKey &&
                variation.price == cart.serviceCost) {
              if (cart.variantKey == cartModel.variantKey &&
                  jsonEncode(cart.fieldAnswers) ==
                      jsonEncode(cartModel.fieldAnswers)) {
                index = _cartList.indexOf(cart);
              }
            }
          });
        }
      }
    }
    return index;
  }

  void setInitialCartList(Service service) {
    _totalPrice = 0;
    _initialCartList = [];
    service.variationsAppFormat?.zoneWiseVariations?.forEach((variation) {
      CartModel cartModel = CartModel(
        service.id!,
        service.id!,
        variation.variantKey!,
        variation.price!,
        0,
        0,
        0,
        0,
        0,
        "",
        0,
        service.tax ?? 0,
        variation.price ?? 0,
        service,
      );
      int index = isAvailableInCart(cartModel, service);
      if (index != -1) {
        cartModel.copyWith(
          id: _cartList[index].id,
          quantity: _cartList[index].quantity,
        );
      }
      _initialCartList.add(cartModel);
    });
    _isButton = false;
  }

  List<CartModel> _replaceCartList() {
    _initialCartList.removeWhere((cart) => cart.quantity < 0);

    for (var initCart in _initialCartList) {
      _cartList.removeWhere(
        (cart) =>
            cart.id.contains(initCart.id) &&
            cart.variantKey.contains(initCart.variantKey),
      );
    }
    _cartList.addAll(_initialCartList);
    _cartList.removeWhere((element) => element.quantity == 0);

    return _cartList;
  }

  Future<void> getProvidersForServices(bool reload) async {
    if (reload || _providerList == null) {
      _providerList = null;
    }
    Response response = await cartRepo.getProvidersForServices(
      checkoutItems.map((e) => e.serviceId).toSet().toList(),
    );
    if (response.statusCode == 200) {
      _providerList = [];
      List<dynamic> list = response.body['content'];

      for (var element in list) {
        providerList!.add(ProviderData.fromJson(element));
      }

      if (_selectedProvider != null &&
          _providerList != null &&
          _providerList!.isNotEmpty) {
        for (int i = 0; i < _providerList!.length; i++) {
          if (_selectedProvider?.id == _providerList![i].id) {
            selectedProviderIndex = i;
          }
        }
      } else {
        selectedProviderIndex = -1;
      }
    } else {
      _providerList = [];
    }
    update();
  }

  void updateProviderSelectedIndex(int index) {
    selectedProviderIndex = index;
    update();
  }

  void updatePreselectedProvider(
    ProviderData? providerData, {
    bool shouldUpdate = true,
  }) {
    _selectedProvider = providerData;

    if (shouldUpdate) {
      update();
    }
  }

  void updateWalletPaymentStatus(bool status, {bool shouldUpdate = true}) {
    _walletPaymentStatus = status;

    if (shouldUpdate) {
      update();
    }
  }

  void updateBookingAmountWithoutCoupon() {
    _couponAmount = CheckoutHelper.calculateDiscount(
      cartList: checkoutItems,
      discountType: DiscountType.coupon,
    );
    _bookingAmountWithoutCoupon =
        CheckoutHelper.calculateTotalAmountWithoutCoupon(
          cartList: checkoutItems,
        );
  }

  bool isOpenPartialPaymentPopup = true;

  Future<void> openWalletPaymentConfirmDialog() async {
    bool initialCheck;
    bool checkAfterUsingCoupon;

    if (_bookingAmountWithoutCoupon > walletBalance) {
      initialCheck = true;
    } else {
      initialCheck = false;
    }
    if (_bookingAmountWithoutCoupon > (walletBalance + _couponAmount)) {
      checkAfterUsingCoupon = true;
    } else {
      checkAfterUsingCoupon = false;
    }

    if (initialCheck != checkAfterUsingCoupon &&
        walletPaymentStatus &&
        isOpenPartialPaymentPopup) {
      showGeneralDialog(
        barrierColor: Colors.black.withValues(alpha: 0.5),
        transitionBuilder: (context, a1, a2, widget) {
          return Transform.scale(
            scale: a1.value,
            child: Opacity(
              opacity: a1.value,
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                        Dimensions.radiusDefault,
                      ),
                      color: Theme.of(context).cardColor,
                    ),

                    child: Stack(
                      alignment: Alignment.topRight,
                      clipBehavior: Clip.none,
                      children: [
                        const WalletPaymentConfirmDialog(),
                        IconButton(
                          padding: const EdgeInsets.all(0),
                          onPressed: () {
                            Get.back();
                            updateWalletPaymentStatus(false);
                          },
                          icon: const NirabIcon(Icons.cancel),
                          color: Theme.of(
                            context,
                          ).textTheme.bodyMedium?.color?.withValues(alpha: 0.6),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: false,
        barrierLabel: '',
        context: Get.context!,
        pageBuilder: (context, animation1, animation2) {
          return Container();
        },
      );
    }
  }

  void showMinimumAndMaximumOrderValueToaster() {
    ConfigModel configModel = Get.find<SplashController>().configModel;

    Get.closeAllSnackbars();

    if (configModel.content!.minBookingAmount != 0 &&
        configModel.content!.minBookingAmount! > totalPrice &&
        _cartList.isNotEmpty) {
      customSnackBar(
        "message",
        customWidget: Row(
          children: [
            NirabIcon(
              Icons.circle,
              color: Colors.white.withValues(alpha: 0.8),
              size: 16,
            ),
            Text(
              "  ${'minimum_booking_amount'.tr} ${PriceConverter.convertPrice(Get.find<SplashController>().configModel.content!.minBookingAmount!)}",
              style: robotoRegular.copyWith(color: Colors.white),
            ),
          ],
        ),
      );
    } else {
      if (configModel.content!.maxBookingAmount != 0 &&
          configModel.content!.maxBookingAmount! < totalPrice &&
          _cartList.isNotEmpty) {
        customSnackBar(
          "message",
          customWidget: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  NirabIcon(
                    Icons.warning_outlined,
                    color: Theme.of(
                      Get.context!,
                    ).cardColor.withValues(alpha: 0.6),
                    size: 16,
                  ),
                  const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                  Flexible(
                    child: Text(
                      " ${'maximum_order_amount_exceed'.tr} "
                      "(${'${'maximum_order_amount'.tr}'
                          ' ${PriceConverter.convertPrice(Get.find<SplashController>().configModel.content!.maxBookingAmount!)}'}) ${"admin_will_verify_this_order".tr}",
                      style: robotoRegular.copyWith(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      }
    }
  }

  Future<void> rebook(String bookingId) async {
    _invalidateBookingContext();
    cartRepo.addRebookToServer(bookingId);
  }

  String maskNumberWithoutCountryCode(String phoneNumber) {
    if (phoneNumber.length <= 6) {
      return phoneNumber;
    }
    String maskedNumber = phoneNumber.substring(
      0,
      phoneNumber.length - 6,
    ); // Keep initial digits

    maskedNumber += '***';
    maskedNumber += phoneNumber.substring(phoneNumber.length - 3);
    return maskedNumber;
  }

  bool checkProviderUnavailability() {
    return _cartList.isNotEmpty &&
        _cartList[0].provider != null &&
        (_cartList[0].provider?.serviceAvailability == 0 ||
            _cartList[0].provider?.isActive == 0 ||
            _cartList[0].provider?.nextBookingEligibility == false);
  }

  String? checkScheduleBookingAvailability() {
    if (Get.find<SplashController>().configModel.content?.scheduleBooking ==
        0) {
      return 'schedule_booking_currently_unavailable'.tr;
    } else if (_cartList.isNotEmpty &&
        _cartList[0].provider != null &&
        (_cartList[0].provider?.scheduleBookingEligibility == false)) {
      return 'schedule_booking_currently_unavailable_for_this_provider'.tr;
    } else {
      return null;
    }
  }
}
